import React from 'react';
import type { ViewId } from '../data/mock';
import { Agentes, Tareas, Artefactos } from './Work';
import { Fronteras, AENC_View, InformeAnualView, Usuarios } from './M2C';
import { MotorReglas } from './Motor';
import { DespachoProgReal, Redespacho, MercadoIntradiario } from './Despacho';
import { Contratos, Posicion, Sicep, Riesgo, EscenariosView } from './Trading';
import { Supervision, Mercado, Admin } from './Ops';
import { PluginsView } from './Plugins';
import { IntegracionesView, ArchivosView, SoporteView } from './Platform';
import { ProcesoView, MiBandeja, MisConversaciones, Equipos, Redirigir } from './ProcesoViews';

const MAP: Record<ViewId, React.FC> = {
  // Trabajo
  inicio: MiBandeja,
  bandeja: MiBandeja,
  conversacion: MisConversaciones,
  agentes: Agentes,
  tareas: Tareas,
  procesos: () => <ProcesoView lista />,
  artefactos: Artefactos,

  // Despacho
  despacho_ofertas: () => <Redirigir pid="wf-despacho-d1" />,
  despacho_prog_real: DespachoProgReal,
  despacho_redespacho: Redespacho,
  despacho_intradiario: MercadoIntradiario,

  // Liquidación
  liquidacion: () => <Redirigir pid="wf-liq-sombra" />,
  motor: MotorReglas,
  garantias: () => <Redirigir pid="wf-garantias" />,
  reclamaciones: () => <Redirigir pid="wf-reclamaciones" />,

  // Facturación
  facturacion: () => <Redirigir pid="wf-facturacion" />,
  facturas_dian: () => <Redirigir pid="wf-facturacion" pestana="envios" />,
  notas_credito: () => <Redirigir pid="wf-facturacion" pestana="datos" />,
  envio_erp: () => <Redirigir pid="wf-facturacion" pestana="envios" />,
  usuarios: Usuarios,

  // CGM / Medida
  fronteras: Fronteras,
  critica: () => <Redirigir pid="wf-critica-m2c" />,
  srm: () => <Redirigir pid="wf-critica-m2c" pestana="envios" />,
  aenc: AENC_View,
  informe_anual: InformeAnualView,

  // ETRM y riesgo
  contratos: Contratos,
  posicion: Posicion,
  sicep: Sicep,
  riesgo: Riesgo,
  escenarios: EscenariosView,

  // Operación y mercado
  supervision: Supervision,
  mercado: Mercado,

  // Plataforma
  plugins: PluginsView,
  integraciones: IntegracionesView,
  archivos: ArchivosView,
  soporte: SoporteView,
  admin: Admin,

  // Arquitectura por procesos
  proceso: () => <ProcesoView />,
  mis_conversaciones: MisConversaciones,
  equipos: Equipos,
};

export function renderView(v: ViewId) {
  const C = MAP[v] || MiBandeja;
  return <C key={v} />;
}
