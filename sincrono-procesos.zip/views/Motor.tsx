import React, { useState } from 'react';
import {
  Play, GitBranch, FileText, Download, Check, AlertCircle, AlertTriangle, ArrowRight,
  Sparkles, CheckCircle2, RotateCcw, HelpCircle, ShieldCheck, ChevronRight, Calculator,
  Database, Bot, Clock, Layers, MessageSquare, Send, CheckCheck
} from 'lucide-react';
import { useApp } from '../components/context';
import { Panel, Kpi, Btn, Table, ViewHeader, StatusBadge, Tabs, Badge, Illustrative, LayerBadge } from '../components/ui';
import { DiffChart } from '../components/charts';
import { SETTLEMENT, VERSIONS, FORMULAS, RECPOS_TREE, FormulaNode, cop, CONTRACTS } from '../data/mock';
import AirtableGrid, { GridRow } from '../components/AirtableGrid';
import ProcessFlowDAG from '../components/workflow/ProcessFlowDAG';
import { WORKFLOWS_REGISTRY } from '../data/workflowModels';

// Process Definitions in the Settlement Cockpit
export type SettlementProcessKey = 'sombra_xm' | 'contratos_energia' | 'unr_usuarios' | 'garantias_asic';

interface ProcessCardInfo {
  key: SettlementProcessKey;
  title: string;
  subtitle: string;
  agent: string;
  hasPending: boolean;
  pendingText: string;
  ruleCode: string;
  capa: 'nucleo' | 'enersinc_cliente' | 'cliente';
}

const PROCESS_CARDS: ProcessCardInfo[] = [
  {
    key: 'sombra_xm',
    title: 'Liquidación Sombra XM',
    subtitle: 'Revisión paralela de versiones oficiales del ASIC (TX1 a TXF)',
    agent: 'Auditor de liquidación (N2)',
    hasPending: true,
    pendingText: 'TX2 de octubre pendiente · 3 diferencias sobre umbral',
    ruleCode: 'CREG 024/1995 · RecPos v14',
    capa: 'nucleo',
  },
  {
    key: 'contratos_energia',
    title: 'Liquidación de Contratos de Energía',
    subtitle: 'Contratos bilaterales, indexaciones IPP/IPC y reglas condicionales',
    agent: 'Contratos de largo plazo (N1)',
    hasPending: true,
    pendingText: 'Contrato condicional C-2026-031 por auditar (Horas 12-14)',
    ruleCode: 'Contratos Bilaterales SICEP',
    capa: 'enersinc_cliente',
  },
  {
    key: 'unr_usuarios',
    title: 'Liquidación de Usuarios No Regulados (UNR)',
    subtitle: 'Cálculo de componentes CU (G, T, D, C, P, R) y prefacturación comercial',
    agent: 'Cargos y facturación (N2)',
    hasPending: true,
    pendingText: '38 prefacturas listas para validación previa CUFE',
    ruleCode: 'Fórmula tarifaria CREG 119/2007',
    capa: 'enersinc_cliente',
  },
  {
    key: 'garantias_asic',
    title: 'Garantías y Obligaciones Financieras',
    subtitle: 'Proyección semanal de obligaciones y cobertura ante el patrimonio autónomo XM',
    agent: 'Proyección de garantías (N1)',
    hasPending: true,
    pendingText: 'Alerta: Brecha semanal de $612 M detectada',
    ruleCode: 'CREG 019/2006 · Garantías MEM',
    capa: 'enersinc_cliente',
  },
];

// Grid Rows for Sombra XM
const SOMBRA_ROWS: GridRow[] = [
  {
    id: 'CONC-01',
    concepto: 'Ventas en bolsa de energía spot',
    categoria: 'Bolsa',
    calc: 18_420_300_000,
    xm: 18_419_900_000,
    diff: 400_000,
    regla: 'CREG 024/1995 Art. 12',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'Ventas_Bolsa = Sum(h=1..24, Gen_Neta(h) * PB(h))',
      explicacion: 'Diferencia de $400.000 COP atribuible a redondeo horario de decimales en el archivo LAC.',
    },
  },
  {
    id: 'CONC-02',
    concepto: 'Compras en bolsa de energía spot',
    categoria: 'Bolsa',
    calc: -6_210_450_000,
    xm: -6_210_450_000,
    diff: 0,
    regla: 'CREG 024/1995 Art. 13',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'Compras_Bolsa = Sum(h=1..24, Demanda_Descubierta(h) * PB(h))',
      explicacion: 'Coincidencia exacta del 100% contra el archivo oficial LAC de XM.',
    },
  },
  {
    id: 'CONC-03',
    concepto: 'Reconciliación positiva de generación',
    categoria: 'Reconciliaciones',
    calc: 1_332_850_000,
    xm: 1_284_500_000,
    diff: 48_350_000,
    regla: 'RecPos v14.2 · CREG 024/1995',
    umbral: 5_000_000,
    estado: 'Reclamar',
    detalles: {
      formula: 'RecPos(u, h) = Max(0, GenReal - DespIdeal) * (Oferta - PB)',
      explicacion:
        'Causa aislada: XM omitió la disponibilidad declarada en el archivo IDO de las 16:42 para la Unidad Térmica 2 en horas 18 a 21. Supera el umbral por $43,35 M.',
    },
  },
  {
    id: 'CONC-04',
    concepto: 'Reconciliación negativa de generación',
    categoria: 'Reconciliaciones',
    calc: -412_300_000,
    xm: -412_300_000,
    diff: 0,
    regla: 'RecNeg v11 · CREG 024/1995',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'RecNeg(u, h) = Max(0, DespIdeal - GenReal) * Costo_Cese',
      explicacion: 'Cuadra plenamente con la publicación de XM.',
    },
  },
  {
    id: 'CONC-05',
    concepto: 'Restricciones de red y operativas',
    categoria: 'Restricciones',
    calc: -288_900_000,
    xm: -301_750_000,
    diff: 12_850_000,
    regla: 'Restr v8 · CREG 025/1995',
    umbral: 5_000_000,
    estado: 'Reclamar',
    detalles: {
      formula: 'Alivio_Restricciones = Asignacion_Demanda * Factor_Area',
      explicacion: 'Discrepancia en la prorrata de pérdidas asociadas al área operativa Caribe.',
    },
  },
  {
    id: 'CONC-06',
    concepto: 'Cargo por confiabilidad (OEF)',
    categoria: 'Confiabilidad',
    calc: 4_870_000_000,
    xm: 4_870_000_000,
    diff: 0,
    regla: 'CxC_OEF v9 · CREG 071/2006',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'CxC = OEF_Asignada * Precio_Escasez_Ponderado',
      explicacion: 'Liquidación conforme de las Obligaciones de Energía Firme.',
    },
  },
  {
    id: 'CONC-07',
    concepto: 'Desviaciones horarias de generación',
    categoria: 'Despacho',
    calc: -96_400_000,
    xm: -96_380_000,
    diff: -20_000,
    regla: 'Desv v6 · CREG 051/2009',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'Desv = |GenReal - DespProg| * Penalidad_Marginal',
      explicacion: 'Delta de $20.000 COP inferior al umbral mínimo de reclamación.',
    },
  },
  {
    id: 'CONC-08',
    concepto: 'Contratos bilaterales despachados',
    categoria: 'Contratos',
    calc: 9_840_000_000,
    xm: 9_840_000_000,
    diff: 0,
    regla: 'Contratos ASIC v4',
    umbral: 5_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'Liquidacion_Contratos = Sum(Contratos_Registrados)',
      explicacion: 'Emparejamiento total de las 12 curvas contractuales registradas.',
    },
  },
  {
    id: 'CONC-09',
    concepto: 'Servicios de operación CND y ASIC',
    categoria: 'Cargos XM',
    calc: -38_200_000,
    xm: -38_200_000,
    diff: 0,
    regla: 'Tarifas CND/ASIC 2026',
    umbral: 1_000_000,
    estado: 'Cuadra',
    detalles: {
      formula: 'Costo_Servicio = Consumo_MWh * Cargo_CND_ASIC',
      explicacion: 'Tarifa oficial fija aplicada a la energía transada.',
    },
  },
  {
    id: 'CONC-10',
    concepto: 'Combustibles reconocidos en generación obligada',
    categoria: 'Reconciliaciones',
    calc: 2_115_000_000,
    xm: 2_089_600_000,
    diff: 25_400_000,
    regla: 'CREG 024/1995 · Auditoría Gas',
    umbral: 5_000_000,
    estado: 'Reclamar',
    detalles: {
      formula: 'Costo_Gas = Consumo_MBTU * (Precio_Boca_Pozo + Tarifa_Transporte)',
      explicacion: 'Diferencia en el índice de transporte de gas TGI reportado en el cálculo preliminar.',
    },
  },
];

// Grid Rows for Contratos de Energía
const CONTRATOS_ROWS: GridRow[] = [
  {
    id: 'CTR-01',
    concepto: 'C-2026-014 · Comercializadora Andina (Venta)',
    categoria: 'Pague lo contratado',
    calc: 4_832_000_000,
    xm: 4_832_000_000,
    diff: 0,
    regla: 'Indexación IPP base 2026',
    umbral: 2_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'Valor = 15.200 MWh * $318/kWh', explicacion: 'Despacho horario 100% conforme.' },
  },
  {
    id: 'CTR-02',
    concepto: 'C-2026-019 · Industrias del Caribe (Venta)',
    categoria: 'Pague lo demandado',
    calc: 1_310_200_000,
    xm: 1_310_200_000,
    diff: 0,
    regla: 'Indexación IPC base 2026',
    umbral: 2_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'Valor = 3.830 MWh * $342/kWh', explicacion: 'Curva horaria de cliente validada.' },
  },
  {
    id: 'CTR-03',
    concepto: 'C-2026-031 · Energía Sabana (Venta Condicional)',
    categoria: 'Condicional Bolsa',
    calc: 1_773_000_000,
    xm: 1_776_500_000,
    diff: -3_500_000,
    regla: 'Regla Cláusula 4.2 · Bolsa > $700',
    umbral: 2_000_000,
    estado: 'Reclamar',
    detalles: {
      formula: 'Despacho condicionado a Precio_Bolsa > $700 COP/kWh',
      explicacion: 'En horas 12 a 14 el precio de bolsa fue $645/kWh, pero se liquidaron 9,6 MWh erróneamente.',
    },
  },
  {
    id: 'CTR-04',
    concepto: 'C-2025-077 · Generadora del Sinú (Compra)',
    categoria: 'Pague lo contratado',
    calc: -2_360_000_000,
    xm: -2_360_000_000,
    diff: 0,
    regla: 'Indexación IPP base 2025',
    umbral: 2_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'Valor = 8.000 MWh * $295/kWh', explicacion: 'Compra base liquidada.' },
  },
  {
    id: 'CTR-05',
    concepto: 'C-2026-042 · Solar Cesar (Compra PPA)',
    categoria: 'PPA Renovable',
    calc: -1_482_000_000,
    xm: -1_482_000_000,
    diff: 0,
    regla: 'PPA Solar FV CREG 030',
    umbral: 2_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'Valor = 6.000 MWh * $247/kWh', explicacion: 'Generación solar fotovoltaica verificada.' },
  },
  {
    id: 'CTR-06',
    concepto: 'SICEP-26-08 · Convocatoria Pública (Venta)',
    categoria: 'Estandarizado SICEP',
    calc: 3_340_000_000,
    xm: 3_340_000_000,
    diff: 0,
    regla: 'Reglamento SICEP XM',
    umbral: 2_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'Valor = 10.000 MWh * $334/kWh', explicacion: 'Obligación SICEP adjudicada.' },
  },
];

// Grid Rows for Usuarios No Regulados (UNR)
const UNR_ROWS: GridRow[] = [
  {
    id: 'UNR-01',
    concepto: 'Cementos del Norte · Planta Barranquilla',
    categoria: 'Industria Pesada',
    calc: 840_200_000,
    xm: 840_200_000,
    diff: 0,
    regla: 'CREG 119/2007 (CU Componentes)',
    umbral: 1_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'CU = G + T + D + C + P + R = $548,2/kWh', explicacion: 'Prefactura conforme sin glosas.' },
  },
  {
    id: 'UNR-02',
    concepto: 'Siderúrgica del Caribe · Horno 1',
    categoria: 'Siderurgia',
    calc: 1_215_400_000,
    xm: 1_215_400_000,
    diff: 0,
    regla: 'CREG 119/2007 (CU Componentes)',
    umbral: 1_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'CU = G + T + D + C + P + R = $539,4/kWh', explicacion: 'Consumo reactivo inductivo dentro de norma.' },
  },
  {
    id: 'UNR-03',
    concepto: 'Alimentos del Valle · Planta 2',
    categoria: 'Agroindustria',
    calc: 320_500_000,
    xm: 334_700_000,
    diff: -14_200_000,
    regla: 'Reliquidación Medida CREG 038',
    umbral: 1_000_000,
    estado: 'Reclamar',
    detalles: {
      formula: 'Ajuste por sustitución de medidor principal',
      explicacion: 'Nota crédito aplicada por corrección de telemedida en frontera Frt-0412.',
    },
  },
  {
    id: 'UNR-04',
    concepto: 'Frigorífico Costa Azul · Cuarto Frío',
    categoria: 'Comercial Frío',
    calc: 198_400_000,
    xm: 198_400_000,
    diff: 0,
    regla: 'Tarifa Regulada CREG',
    umbral: 1_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'CU estándar nivel de tensión 2', explicacion: 'Consumo conforme.' },
  },
  {
    id: 'UNR-05',
    concepto: 'Vidrios Andinos · Horno Continuo',
    categoria: 'Manufactura',
    calc: 465_100_000,
    xm: 465_100_000,
    diff: 0,
    regla: 'CREG 119/2007 (CU Componentes)',
    umbral: 1_000_000,
    estado: 'Cuadra',
    detalles: { formula: 'CU = G + T + D + C + P + R', explicacion: 'Lectura telemétrica 100% validada.' },
  },
];


// ---------- Motor de Reglas (Tree & Tests) ----------
function TreeNode({
  n,
  depth,
  sel,
  onSel,
}: {
  n: FormulaNode;
  depth: number;
  sel: string;
  onSel: (s: string) => void;
}) {
  return (
    <div className={depth ? 'ml-5 border-l-2 border-line pl-3' : ''}>
      <button
        onClick={() => onSel(n.name)}
        className={`block text-left py-1 ${sel === n.name ? 'text-brand font-semibold' : 'text-txt'}`}
      >
        <span className="text-xs">{n.name}</span>
        {n.source && <span className="block text-[11px] text-mut">{n.source}</span>}
      </button>
      {n.children?.map(c => (
        <TreeNode key={c.name} n={c} depth={depth + 1} sel={sel} onSel={onSel} />
      ))}
    </div>
  );
}

export function MotorReglas() {
  const [f, setF] = useState(0);
  const [sel, setSel] = useState(RECPOS_TREE.name);
  const [tested, setTested] = useState(false);
  const cur = FORMULAS[f];

  return (
    <>
      <ViewHeader
        title="Motor de reglas y árbol de dependencias"
        desc="Fórmulas versionadas por vigencia CREG con fecha de inicio y fin. Un cambio regulatorio nunca reescribe el histórico. Las reglas contractuales del cliente se configuran sobre el mismo motor sin código."
        capa="nucleo"
        actions={
          <Btn kind="primary">
            <GitBranch size={14} /> Nueva vigencia de regla
          </Btn>
        }
      />

      <div className="grid lg:grid-cols-12 gap-4">
        {/* Formulas List */}
        <Panel className="lg:col-span-4" title="Fórmulas vigentes e históricas" pad={false}>
          <ul>
            {FORMULAS.map((x, i) => (
              <li key={i}>
                <button
                  onClick={() => setF(i)}
                  className={`w-full text-left px-4 py-2.5 border-b border-line last:border-0 transition-colors ${
                    i === f ? 'bg-brandsoft/50 border-l-4 border-brand' : 'hover:bg-paper'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs text-txt">{x.code}</span>
                    <span className="text-[11px] text-mut font-mono">v{x.version}</span>
                    <span className="ml-auto">
                      <StatusBadge s={x.status} />
                    </span>
                  </div>
                  <div className="text-xs text-mut mt-0.5">{x.name}</div>
                  <div className="text-[10px] text-mut flex justify-between mt-1">
                    <span>Vigencia: {x.from} → {x.to}</span>
                    <LayerBadge capa={x.capa} compact />
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </Panel>

        {/* Selected Formula & Dependency Graph */}
        <div className="lg:col-span-8 space-y-4">
          <Panel
            title={`${cur.code} v${cur.version} · ${cur.name}`}
            action={<Badge tone="brand">Vigencia {cur.from} → {cur.to}</Badge>}
          >
            <pre className="text-xs bg-ink text-[#D7E0EE] rounded p-3 overflow-x-auto leading-relaxed font-mono">
              {`-- Expresión matemática oficial CREG
RecPos[h] = max(0, GenReal[h] - GenIdeal[h]) * PrecioRec[h]

-- SQL compilado automáticamente sobre BigQuery Lake
SELECT 
  h.fecha, 
  h.hora, 
  h.planta_id,
  GREATEST(0, h.gen_real_mwh - h.gen_ideal_mwh) * h.precio_rec_cop AS recpos_monto
FROM \`enersinc_os_prod.mem_colombia.horario_planta\` h
WHERE h.version_liquidacion = @version 
  AND h.fecha BETWEEN @desde AND @hasta;`}
            </pre>
          </Panel>

          <div className="grid md:grid-cols-2 gap-4">
            <Panel title="Árbol de dependencias causal">
              <p className="text-[11px] text-mut mb-2">
                Haga clic en cualquier nodo para trazar el origen primario del dato:
              </p>
              <TreeNode n={RECPOS_TREE} depth={0} sel={sel} onSel={setSel} />
            </Panel>

            <Panel title="Probar fórmula contra datos reales">
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  ['Versión', 'TX2'],
                  ['Fecha', '21-oct-2026'],
                  ['Planta', 'Unidad 2 Térmica'],
                  ['Horas evaluadas', '18 a 21'],
                ].map(([l, v]) => (
                  <label key={l} className="block">
                    <span className="text-[11px] text-mut">{l}</span>
                    <input defaultValue={v} className="mt-0.5 w-full border border-line rounded px-2 py-1 text-xs font-medium" />
                  </label>
                ))}
              </div>
              <div className="mt-3">
                <Btn kind="primary" onClick={() => setTested(true)}>
                  <Play size={13} /> Ejecutar prueba en sandbox
                </Btn>
              </div>

              {tested && (
                <div className="mt-3 text-xs bg-paper rounded p-3 border border-line animate-in fade-in">
                  <div className="text-bad font-semibold">
                    Resultado: +$48,4 M COP de diferencia contra publicación XM
                  </div>
                  <div className="text-mut text-[11px] mt-1">
                    Nodo causal aislado: <b>Disponibilidad declarada (horas 18–21)</b>.
                  </div>
                </div>
              )}
            </Panel>
          </div>
        </div>
      </div>

      <Illustrative />
    </>
  );
}

