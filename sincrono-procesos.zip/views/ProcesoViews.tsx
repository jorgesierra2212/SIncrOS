import React, { useEffect, useState } from 'react';
import { Search, ArrowRight, Inbox, Send, Workflow, Users, MessagesSquare, ShieldCheck } from 'lucide-react';
import { useApp } from '../components/context';
import { useProcess } from '../components/process/ProcessStore';
import ProcessWorkspace from '../components/process/ProcessWorkspace';
import ChatPanel, { ListaConversaciones } from '../components/process/ChatPanel';
import { Badge, Btn, StatusBadge, ViewHeader } from '../components/ui';
import { PROFILES } from '../data/mock';
import { EQUIPOS, PROCESOS, procesoPorId, procesosVisibles, rolDe } from '../data/process/catalog';
import { DOMINIOS } from '../data/process/types';
import type { PestanaProceso } from '../data/process/types';

// ---------- Proceso ----------
export function ProcesoView({ lista = false }: { lista?: boolean }) {
  const { activo, visibles, abrir, ejecucionActiva } = useProcess();
  const p = !lista && activo ? visibles.find(x => x.id === activo) ?? null : null;
  if (p) return <ProcessWorkspace p={p} />;
  return (
    <>
      <ViewHeader title="Procesos" desc="Seleccione un proceso. Todos se trabajan con los mismos siete componentes." />
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {visibles.map(x => {
          const e = ejecucionActiva(x.id);
          return (
            <button key={x.id} onClick={() => abrir(x.id)} className="text-left bg-white border border-line rounded-lg p-4 hover:border-brand">
              <div className="text-xs text-mut">{x.dominio} · {x.codigo}</div>
              <div className="font-semibold mt-0.5">{x.nombre}</div>
              <div className="text-xs text-mut mt-1 line-clamp-2">{x.descripcion}</div>
              <div className="flex items-center gap-2 mt-3"><StatusBadge s={e.estado} /><span className="text-xs text-mut truncate">{e.fecha}{e.version ? ' · ' + e.version : ''}</span></div>
            </button>
          );
        })}
      </div>
    </>
  );
}

/** Redirige las vistas antiguas al proceso que las reemplaza. */
export function Redirigir({ pid, pestana = 'flujo' }: { pid: string; pestana?: PestanaProceso }) {
  const { abrir } = useProcess();
  useEffect(() => { abrir(pid, pestana); }, [pid]);
  return null;
}

// ---------- Mi bandeja ----------
export function MiBandeja() {
  const { bandeja, abrir, visibles, ejecucionActiva, rol } = useProcess();
  const { profile, approvals, decisions, openTrace, traces } = useApp();
  const legado = approvals.filter(a => !decisions[a.id] && traces[a.id] && (a.role === profile.role || profile.id === 'ger'));
  return (
    <>
      <ViewHeader title={`Mi bandeja · ${profile.person}`} desc="Pasos humanos y envíos que esperan su decisión en los procesos donde usted aprueba. Quien ejecuta no aprueba." />
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-2">
          {bandeja.length === 0 && legado.length === 0 && (
            <div className="bg-white border border-line rounded-lg p-6 text-sm text-mut">No tiene decisiones pendientes. Cambie de persona abajo a la izquierda para ver otra bandeja.</div>
          )}
          {bandeja.map(i => (
            <button key={i.id} onClick={() => abrir(i.proceso.id, i.tipo === 'envio' ? 'envios' : 'flujo', i.ejecucion.id)}
              className="w-full text-left bg-white border border-line rounded-lg p-3.5 hover:border-brand flex items-start gap-3">
              <span className={`mt-0.5 w-8 h-8 rounded-full grid place-items-center shrink-0 ${i.tipo === 'envio' ? 'bg-brandsoft text-brand' : 'bg-warnsoft text-warn'}`}>
                {i.tipo === 'envio' ? <Send size={15} /> : <ShieldCheck size={15} />}
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-xs text-mut">{i.tipo === 'envio' ? 'Envío por aprobar' : 'Paso humano por aprobar'} · {i.proceso.dominio}</span>
                <span className="block font-medium">{i.titulo}</span>
                <span className="block text-xs text-mut truncate">{i.detalle}</span>
              </span>
              <ArrowRight size={16} className="text-mut mt-2" />
            </button>
          ))}
          {legado.length > 0 && (
            <div className="pt-3">
              <div className="text-xs text-mut mb-1.5">Evidencia detallada preparada por los agentes</div>
              {legado.map(a => (
                <button key={a.id} onClick={() => openTrace(a.id)} className="w-full text-left bg-white border border-line rounded-lg p-3 mb-2 hover:border-brand">
                  <div className="text-xs text-mut">{a.id} · {a.agent}</div>
                  <div className="text-sm font-medium">{a.title}</div>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="bg-white border border-line rounded-lg p-4 h-fit">
          <h3 className="text-sm font-semibold flex items-center gap-1.5 mb-3"><Workflow size={15} /> Mis procesos</h3>
          <ul className="space-y-2">
            {visibles.map(x => {
              const e = ejecucionActiva(x.id);
              return (
                <li key={x.id}>
                  <button onClick={() => abrir(x.id)} className="w-full text-left rounded-md px-2 py-1.5 hover:bg-paper">
                    <div className="flex items-center gap-2"><span className="text-sm font-medium flex-1 truncate">{x.nombre}</span><Badge tone="neutral">{rol(x.id)}</Badge></div>
                    <div className="flex items-center gap-2 mt-0.5"><StatusBadge s={e.estado} /><span className="text-xs text-mut truncate">{e.pasoActual}</span></div>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </>
  );
}

// ---------- Mis conversaciones ----------
export function MisConversaciones() {
  const { misConversaciones, convActiva, setConvActiva, abrir, ejecuciones, nuevaConversacion } = useProcess();
  const { profile } = useApp();
  const [q, setQ] = useState('');
  const [filtro, setFiltro] = useState<'Todas' | 'Propias' | 'Compartidas conmigo'>('Todas');
  const lista = misConversaciones
    .filter(c => filtro === 'Todas' || (filtro === 'Propias' ? c.dueno === profile.id : c.dueno !== profile.id))
    .filter(c => (c.titulo + ' ' + c.mensajes.map(m => m.text).join(' ')).toLowerCase().includes(q.toLowerCase()));
  const activa = lista.find(c => c.id === convActiva) ?? lista[0] ?? null;

  useEffect(() => { if (activa && activa.id !== convActiva) setConvActiva(activa.id); }, [activa?.id]);

  const contexto = (pid?: string, eid?: string) => {
    if (!pid) return 'General';
    const e = ejecuciones.find(x => x.id === eid);
    return `${procesoPorId(pid)?.nombre} · ${e?.fecha ?? ''}${e?.version ? ' ' + e.version : ''}`;
  };

  return (
    <>
      <ViewHeader title="Mis conversaciones" desc="Sus conversaciones y las que otros compartieron con usted. Al retomarlas, el agente recibe el contexto del proceso y la ejecución en su estado actual."
        actions={<Btn kind="primary" onClick={() => nuevaConversacion()}>Nueva conversación</Btn>} />
      <div className="grid lg:grid-cols-[320px_1fr] gap-4">
        <div className="bg-white border border-line rounded-lg">
          <div className="p-2.5 border-b border-line space-y-2">
            <label className="flex items-center gap-2 bg-paper rounded-md px-2.5 py-1.5 text-sm">
              <Search size={14} className="text-mut" />
              <input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar en conversaciones" className="bg-transparent outline-none flex-1" />
            </label>
            <div className="flex gap-1">
              {(['Todas', 'Propias', 'Compartidas conmigo'] as const).map(f => (
                <button key={f} onClick={() => setFiltro(f)} className={`text-xs rounded px-2 py-1 ${filtro === f ? 'bg-ink text-white' : 'text-mut hover:bg-paper'}`}>{f}</button>
              ))}
            </div>
          </div>
          <ul className="max-h-[560px] overflow-y-auto">
            {lista.map(c => (
              <li key={c.id}>
                <button onClick={() => setConvActiva(c.id)} className={`w-full text-left px-3 py-2.5 border-b border-line ${c.id === activa?.id ? 'bg-brandsoft' : 'hover:bg-paper'}`}>
                  <div className="text-sm font-medium truncate">{c.titulo}</div>
                  <div className="text-xs text-mut truncate">{contexto(c.procesoId, c.ejecucionId)}</div>
                  <div className="text-[11px] text-mut">{c.actualizada}{c.dueno !== profile.id ? ` · de ${PROFILES.find(p => p.id === c.dueno)?.person}` : ''}</div>
                </button>
              </li>
            ))}
            {lista.length === 0 && <li className="p-4 text-sm text-mut">Sin resultados.</li>}
          </ul>
        </div>
        <div className="space-y-2">
          {activa?.procesoId && (
            <div className="flex items-center gap-2 text-sm bg-white border border-line rounded-lg px-3 py-2">
              <MessagesSquare size={14} className="text-brand" />
              <span className="flex-1 truncate">Ligada a <b>{contexto(activa.procesoId, activa.ejecucionId)}</b></span>
              <Btn small onClick={() => abrir(activa.procesoId!, 'chat', activa.ejecucionId)}>Retomar en el proceso</Btn>
            </div>
          )}
          <ChatPanel convId={activa?.id ?? null} alto="h-[600px]" />
        </div>
      </div>
    </>
  );
}

// ---------- Equipos ----------
export function Equipos() {
  const { profile } = useApp();
  const { abrir } = useProcess();
  const persona = (id: string) => PROFILES.find(p => p.id === id);
  return (
    <>
      <ViewHeader title="Equipos" desc="Los procesos se comparten por equipos. Dentro de cada proceso, el rol define qué puede hacer cada persona: Dueño configura, Ejecutor ejecuta y edita, Aprobador aprueba, Lector consulta." />
      <div className="grid md:grid-cols-2 gap-4">
        {EQUIPOS.map(eq => (
          <div key={eq.id} className={`bg-white border rounded-lg p-4 ${eq.miembros.includes(profile.id) ? 'border-brand' : 'border-line'}`}>
            <div className="flex items-center gap-2 mb-2">
              <Users size={15} className="text-brand" /><h3 className="font-semibold flex-1">{eq.nombre}</h3>
              {eq.miembros.includes(profile.id) && <Badge tone="brand">Su equipo</Badge>}
            </div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {eq.miembros.map(m => <Badge key={m} tone="neutral">{persona(m)?.person}</Badge>)}
            </div>
            <ul className="space-y-1">
              {eq.procesos.map(pid => {
                const p = procesoPorId(pid)!;
                return (
                  <li key={pid} className="flex items-center gap-2 text-sm">
                    <button onClick={() => abrir(pid)} className="text-brand hover:underline flex-1 text-left truncate">{p.nombre}</button>
                    <span className="text-xs text-mut hidden sm:inline">{eq.miembros.map(m => `${persona(m)?.initials}: ${rolDe(m, p)}`).join(' · ')}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
      <div className="bg-white border border-line rounded-lg mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="text-left text-mut"><th className="px-3 py-2 font-medium">Proceso</th>{PROFILES.map(p => <th key={p.id} className="px-3 py-2 font-medium whitespace-nowrap">{p.person}</th>)}</tr></thead>
          <tbody>
            {DOMINIOS.flatMap(d => PROCESOS.filter(p => p.dominio === d)).map(p => (
              <tr key={p.id} className="border-t border-line">
                <td className="px-3 py-2 whitespace-nowrap">{p.nombre}</td>
                {PROFILES.map(x => <td key={x.id} className={`px-3 py-2 ${x.id === profile.id ? 'bg-brandsoft/50' : ''}`}><span className="text-xs">{procesosVisibles(x.id).some(v => v.id === p.id) ? rolDe(x.id, p) : '—'}</span></td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
