// Orquestador y enrutador agéntico de Enersinc OS.
// Integra llamada a /api/chat (servidor con Modelo configurado) y fallback inteligente local
// respetando los principios del MEM colombiano (CREG, XM, TX1-TXF, propuestas sin auto-ejecución).

import type { ArchivoItem } from './types';

export type InlineChart = 'bolsa' | 'diferencias' | 'garantias' | 'fronteras' | 'escenarios';

export interface AgentReply {
  agent: string;
  text: string;
  steps: string[];
  chart?: InlineChart;
  artifact?: string;
  approval?: string;
  layer?: 'nucleo' | 'enersinc_cliente' | 'cliente';
  commandUsed?: string;
  mentionUsed?: string;
  attachedCount?: number;
}

export interface ChatMsg {
  role: 'user' | 'agent';
  text: string;
  reply?: AgentReply;
  files?: ArchivoItem[];
  command?: string;
  mention?: string;
}

export interface PredefinedQnA {
  id: string;
  category: 'Liquidación y XM' | 'Medida y CGM' | 'Contratos y Facturación' | 'Garantías y Finanzas' | 'Despacho y Operación';
  roleRecommended: string;
  question: string;
  shortDesc: string;
  reply: AgentReply;
}

export { PREDEFINED_QNAS } from './agentQnas';
import { PREDEFINED_QNAS } from './agentQnas';

export const SUGGESTIONS = PREDEFINED_QNAS.slice(0, 5).map(q => q.question);

export const AVAILABLE_COMMANDS = [
  { cmd: '/liquidar', desc: 'Compara la versión publicada de XM con el cálculo sombra propio', agent: 'Auditor de liquidación' },
  { cmd: '/srm', desc: 'Prepara y valida el archivo para el Sistema Registro de Medidas', agent: 'Reporte SRM' },
  { cmd: '/garantias', desc: 'Calcula la proyección semanal y la brecha ante el ASIC', agent: 'Proyección de garantías' },
  { cmd: '/facturar', desc: 'Genera prefacturas y valida componentes CU (G, T, D, C, P, R)', agent: 'Cargos y facturación' },
  { cmd: '/ofertar', desc: 'Construye la curva de precio de oferta y disponibilidad por hora', agent: 'Agente de despacho y ofertas' },
  { cmd: '/despacho', desc: 'Compara despacho programado frente a real y alerta desbalances', agent: 'Agente de despacho y ofertas' },
];

export const AVAILABLE_MENTIONS = [
  { tag: '@aud-liq', name: 'Auditor de liquidación', team: 'Liquidación' },
  { tag: '@critica', name: 'Crítica de medida', team: 'CGM' },
  { tag: '@srm', name: 'Reporte SRM', team: 'CGM' },
  { tag: '@despacho-ag', name: 'Agente de despacho y ofertas', team: 'Despacho' },
  { tag: '@garantias', name: 'Proyección de garantías', team: 'Liquidación' },
  { tag: '@facturacion', name: 'Cargos y facturación', team: 'Finanzas' },
  { tag: '@mesa', name: 'Mesa de ayuda', team: 'CGM' },
];

const has = (t: string, ...k: string[]) => k.some(x => t.includes(x));

// Fallback contextual router
export function respondLocally(
  input: string,
  attachedFiles: ArchivoItem[] = [],
  command?: string,
  mention?: string,
  viewContext: string = 'inicio'
): AgentReply {
  const t = input.toLowerCase();

  // If command used
  if (command === '/liquidar' || has(t, '/liquidar')) {
    return {
      agent: 'Auditor de liquidación',
      layer: 'nucleo',
      text: 'Ejecuté la liquidación sombra para contrastar la versión TX2 oficial de XM. Se detectaron 3 conceptos con diferencias por encima del umbral de $5 M. La mayor diferencia se encuentra en Reconciliación Positiva (+$48,4 M) concentrada en la Unidad 2, horas 18 a 21. La reclamación borrador ART-104 ya fue preparada con soporte horario y espera su revisión.',
      steps: [
        'Descargó archivo LAC_20261021.txt desde el FTP de XM',
        'Corrió el motor de reglas CREG 024 con regla RecPos v14',
        'Cotejó contra despacho ideal y archivo IDO de disponibilidad declarada',
        'Generó expediente de reclamación comercial borrador (ART-104)',
      ],
      chart: 'diferencias',
      artifact: 'ART-104',
      approval: 'A-1042',
      commandUsed: '/liquidar',
    };
  }

  if (command === '/srm' || has(t, '/srm')) {
    return {
      agent: 'Reporte SRM',
      layer: 'nucleo',
      text: 'Procesé las 1.284 fronteras comerciales activas para la transmisión diaria al SRM de XM. 1.272 tienen lectura íntegra de telemedida y 12 fueron estimadas siguiendo la jerarquía oficial CREG 038/2014 (usando medidor de respaldo). El archivo estructurado ART-118 cumple la especificación técnica v4.2 y requiere su aprobación antes del corte de las 10:00 COT.',
      steps: [
        'Consolidó curvas de carga horarias de los concentradores Itron, Elster y ION',
        'Aplicó reglas de estimación oficial para 12 fronteras con enlace degradado',
        'Validó sintaxis y sumatorias de energía horaria sin inconsistencias',
        'Preparó archivo de transmisión ART-118 y solicitud de aprobación A-1043',
      ],
      chart: 'fronteras',
      artifact: 'ART-118',
      approval: 'A-1043',
      commandUsed: '/srm',
    };
  }

  if (command === '/garantias' || has(t, '/garantias')) {
    return {
      agent: 'Proyección de garantías',
      layer: 'enersinc_cliente',
      text: 'Efectué la corrida de proyección de garantías conforme a la Resolución CREG 159/2011 para las próximas 6 semanas. Para la semana del 3 de noviembre se proyecta una obligación de $3.418 M frente a un cupo provisionado en banco de $2.806 M (brecha de $612 M), asumiendo bolsa media de $910/kWh. Si el precio de bolsa promedia $750/kWh, la necesidad baja a $2.950 M.',
      steps: [
        'Tomó posición neta horaria proyectada con contratos registrados en el ASIC',
        'Simuló curva de compras netas en bolsa y cargos por restricciones',
        'Calculó cupo semanal obligatorio y comparó contra provisión en tesorería',
        'Generó alerta temprana A-1045 para Finanzas',
      ],
      chart: 'garantias',
      artifact: 'ART-110',
      approval: 'A-1045',
      commandUsed: '/garantias',
    };
  }

  if (command === '/facturar' || has(t, '/facturar')) {
    return {
      agent: 'Cargos y facturación',
      layer: 'enersinc_cliente',
      text: 'El lote de prefacturas de octubre para los 38 usuarios no regulados se encuentra generado y validado contra el mes anterior (+11,4 % en volumen, acorde a demanda estacional). El monto total bruto es de $2.940 M con 2 notas crédito por reliquidación de restricciones. Recuerde que el envío fiscal hacia la DIAN y la causación en el ERP SAP se ejecutarán únicamente tras su aprobación en la Bandeja.',
      steps: [
        'Calculó componentes tarifarios CU (G, T, D, C, P, R) según fórmula CREG 119/2007',
        'Construyó matriz maestra de consumos con telemedidas certificadas',
        'Verificó variaciones relativas vs septiembre (todas dentro de bandas esperadas)',
        'Estructuró prefacturas borrador en aprobación A-1046',
      ],
      artifact: 'ART-115',
      approval: 'A-1046',
      commandUsed: '/facturar',
    };
  }

  if (command === '/ofertar' || command === '/despacho' || has(t, '/ofertar', '/despacho', 'oferta', 'disponibilidad', 'despacho programado')) {
    return {
      agent: 'Agente de despacho y ofertas',
      layer: 'enersinc_cliente',
      text: 'En el seguimiento de despacho de hoy, la Unidad 2 de Planta Térmica Norte presenta una desviación negativa de 21,6 MW por debajo del despacho programado desde las 17:00 COT debido a una restricción imprevista de presión en el gasoducto. El costo estimado en bolsa acumulado es de $98 M con pérdida de $31 M en reconciliación. Recomiendo redeclarar disponibilidad a 120 MW ante el CND y notificar a Liquidación.',
      steps: [
        'Comparó telemetría SCADA en tiempo real vs Despacho Programado DPD',
        'Identificó desbalance sostenido en horas 17 a 21 (108 MWh acumulados)',
        'Valoró penalización a precio spot de bolsa ($690/kWh)',
        'Construyó borrador de redeclaración IDO ante el CND',
      ],
      chart: 'escenarios',
      artifact: 'ART-101',
      commandUsed: command || '/despacho',
    };
  }

  // Files attached processing
  if (attachedFiles.length > 0) {
    const file = attachedFiles[0];
    return {
      agent: 'Analista de datos y archivos',
      layer: 'nucleo',
      text: `He recibido el archivo "${file.nombre}" (${file.tipo.toUpperCase()}, ${file.tamano}). He analizado su estructura: ${file.detalles?.hojas ? `contiene las hojas [${file.detalles.hojas.join(', ')}] con ${file.detalles.filas || 0} registros` : file.detalles?.paginas ? `documento PDF de ${file.detalles.paginas} páginas` : 'archivo presentado'}. Los datos están disponibles para ser usados como entrada en los skills de liquidación sombra o crítica de medida.`,
      steps: [
        'Cargó y analizó el archivo en memoria usando SheetJS / parser',
        'Validó esquema de columnas requeridas por el MEM',
        'Mapeó variables a tablas analíticas del espacio de trabajo',
      ],
      attachedCount: attachedFiles.length,
    };
  }

  // Suggested questions and NLP routing
  if (has(t, 'embalse', 'bolsa', 'hidrolog', 'precio')) {
    if (has(t, 'exposici', 'seco', 'escenario', 'riesgo')) return exposure();
    return {
      agent: 'Analista de despacho y mercado',
      layer: 'nucleo',
      text: 'El nivel de los embalses en el MEM no fija mecánicamente el precio de bolsa: fija el costo de oportunidad del agua en la oferta de las plantas hidráulicas, que actúan como recurso marginal en la mayoría de horas. La relación tiene umbrales críticos: por debajo del 45 % de embalse útil, cada punto porcentual de descenso incrementa el precio marginal significativamente más que por encima del 55 %. Actualmente el embalse agregado está en 64 % y la bolsa promedia $690/kWh.',
      steps: [
        'Consultó series horarias de precio de bolsa y recurso marginal en BigQuery Lake',
        'Cruzó con volumen útil de embalse diario reportado por XM',
        'Calculó mediana de precio por tramo de embalse (tramo 60–70 %: $232/kWh)',
        'Generó gráfico interactivo y lo asoció al artefacto ART-101',
      ],
      chart: 'bolsa',
      artifact: 'ART-101',
    };
  }

  if (has(t, 'liquidaci', 'tx2', 'tx1', 'tx3', 'txr', 'txf', 'difer', 'reclam', 'reconcilia', 'xm')) {
    return {
      agent: 'Auditor de liquidación',
      layer: 'nucleo',
      text: 'En la versión TX2 del 21 de octubre existen 3 conceptos con diferencias superiores al umbral de control. La discrepancia más relevante se encuentra en Reconciliación Positiva: calculamos $1.332,9 M frente a $1.284,5 M liquidados por XM (diferencia de +$48,4 M). El árbol de dependencias de la regla RecPos v14 evidencia que XM utilizó la disponibilidad declarada previa a la redeclaración de las 16:42 en las horas 18–21. El borrador formal de reclamación ART-104 está en su Bandeja para aprobación.',
      steps: [
        'Descargó publicaciones oficiales TX2 desde el repositorio XM',
        'Ejecutó motor de reglas CREG 024/1995 (regla RecPos v14 vigente)',
        'Comparó 10 conceptos comerciales aplicando umbral de $5 M',
        'Aisló variable primaria en el nodo GenIdeal -> Disponibilidad declarada',
        'Redactó reclamación formal y la envió a Bandeja de aprobación A-1042',
      ],
      chart: 'diferencias',
      artifact: 'ART-104',
      approval: 'A-1042',
    };
  }

  if (has(t, 'garant', 'provisi', 'caja', 'cupo')) {
    return {
      agent: 'Proyección de garantías',
      layer: 'enersinc_cliente',
      text: 'Para la semana comercial del 3 de noviembre se proyecta una exigencia de garantía ante el ASIC de $3.418 M, frente a un respaldo bancario provisionado de $2.806 M (brecha de liquidez de $612 M). El supuesto del escenario medio considera bolsa en $910/kWh. Si el precio baja a $750/kWh, la necesidad desciende a $2.950 M. He dejado la propuesta de provisión en la Bandeja de Finanzas (A-1045).',
      steps: [
        'Calculó posición neta horaria con contratos vigentes registrados en el ASIC',
        'Aplicó curva de precios spot del escenario medio de hidrología',
        'Calculó garantía semanal aplicando metodología CREG 159/2011',
        'Comparó contra cupo bancario activo y emitió propuesta A-1045',
      ],
      chart: 'garantias',
      artifact: 'ART-110',
      approval: 'A-1045',
    };
  }

  if (has(t, 'frontera', 'comunicaci', 'medidor', 'srm', 'lectura', 'cgm')) {
    return {
      agent: 'Crítica de medida',
      layer: 'nucleo',
      text: 'En el ciclo de hoy se vigilaron 1.284 fronteras comerciales: 6 presentan enlace caído y 21 tienen alertas de crítica. La anomalía prioritaria es Frt-0412 (Generación térmica): su medidor principal presenta un desfase de 1 hora reloj desde el 18 de octubre y discrepa 6,8 % con el respaldo (41,2 MWh comprometidos). Propuse sustituir con el medidor de respaldo y emitir orden técnica. El archivo diario SRM tiene 12 lecturas estimadas y espera su aprobación.',
      steps: [
        'Monitoreó estado de enlace IP/GPRS de 1.284 medidores comerciales',
        'Corrió algoritmo de crítica diaria (desfase, faltantes y principal vs respaldo)',
        'Priorizó frontera Frt-0412 por impacto en liquidación horaria',
        'Generó propuesta de reemplazo por respaldo A-1044 y archivo SRM ART-118',
      ],
      chart: 'fronteras',
      artifact: 'ART-121',
      approval: 'A-1044',
    };
  }

  if (has(t, 'exposici', 'riesgo', 'par', 'seco', 'escenario')) {
    return exposure();
  }

  // Default agent response
  const agentName = mention ? AVAILABLE_MENTIONS.find(m => m.tag === mention)?.name || 'Asistente Enersinc' : 'Asistente Enersinc';
  return {
    agent: agentName,
    layer: 'nucleo',
    text: `Estoy a su disposición como experto en el Mercado de Energía Mayorista colombiano. Puedo asistirle en liquidación sombra (TX1–TXF), crítica de medida CGM, reporte SRM, garantías ante el ASIC, contratos bilaterales, despacho y análisis de riesgo. Puede usar comandos como /liquidar, /srm o /garantias, o escribir su consulta en lenguaje natural.`,
    steps: [
      'Identificó la consulta en el contexto de mercado',
      'Listo para formular propuestas para validación humana',
    ],
  };
}

function exposure(): AgentReply {
  return {
    agent: 'Analista de despacho y mercado',
    layer: 'enersinc_cliente',
    text: 'Actualmente el 21 % de la demanda que usted atiende se encuentra expuesta a precio de bolsa spot, muy cerca de su límite de política de riesgo (25 %). En un escenario hidrológico seco con incrementos mensuales de bolsa de ~$60/kWh hasta abril de 2027, la pérdida en riesgo (PaR 95 %, 30 días) aumentaría de $3,9 mil M a $4,9 mil M, bordeando el límite prudencial de $5 mil M. Adjudicar la convocatoria SICEP-26-08 por 120 GWh reduciría la exposición al 16 %.',
    steps: [
      'Calculó posición neta horaria a partir de compras y ventas de contratos vigentes',
      'Modeló 3 escenarios hidrológicos (seco, medio y húmedo)',
      'Calculó Pérdida en Riesgo (PaR 95 % a 30 días) contra límites corporativos',
      'Evaluó impacto de cierre de ofertas abiertas en el SICEP',
    ],
    chart: 'escenarios',
    artifact: 'ART-112',
  };
}

// Main dispatcher function: Prioritizes predefined answers for instant agility
export async function askAgent(
  text: string,
  history: ChatMsg[] = [],
  attachedFiles: ArchivoItem[] = [],
  command?: string,
  mention?: string,
  viewContext: string = 'inicio'
): Promise<AgentReply> {
  const norm = text.trim().toLowerCase();

  // 1. Instant lookup in Predefined Q&As (Zero latency, immediate response)
  const exactMatch = PREDEFINED_QNAS.find(q =>
    q.question.toLowerCase() === norm ||
    norm.includes(q.question.toLowerCase()) ||
    q.question.toLowerCase().includes(norm) && norm.length > 15
  );
  if (exactMatch) {
    return { ...exactMatch.reply };
  }

  // 2. Direct command shortcuts (Instant local execution)
  if (command || norm.startsWith('/')) {
    return respondLocally(text, attachedFiles, command, mention, viewContext);
  }

  // 3. Keyword-based immediate match for common regulatory queries
  if (has(norm, 'tx2', 'liquidaci', 'reconcilia', 'art-104')) {
    const q = PREDEFINED_QNAS.find(x => x.id === 'q-liq-tx2');
    if (q) return { ...q.reply };
  }
  if (has(norm, 'srm', 'jerarqu', 'creg 038', 'estimac')) {
    const q = PREDEFINED_QNAS.find(x => x.id === 'q-cgm-srm');
    if (q) return { ...q.reply };
  }
  if (has(norm, 'garant', 'semana', 'provisi', '3 de noviembre')) {
    const q = PREDEFINED_QNAS.find(x => x.id === 'q-gar-semana');
    if (q) return { ...q.reply };
  }
  if (has(norm, 'frt-0412', 'desfase', 'reloj')) {
    const q = PREDEFINED_QNAS.find(x => x.id === 'q-cgm-frt0412');
    if (q) return { ...q.reply };
  }
  if (has(norm, 'prefactura', 'no regulado', 'unr', 'dian')) {
    const q = PREDEFINED_QNAS.find(x => x.id === 'q-fac-unr');
    if (q) return { ...q.reply };
  }

  // 4. Try server API with strict 2-second timeout to avoid any sluggishness
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        prompt: text,
        history: history.slice(-4),
        attachedFiles,
        command,
        mention,
        viewContext,
      }),
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (!data.fallback && data.reply?.text) {
        return {
          agent: data.reply.agent || 'Asistente Enersinc',
          text: data.reply.text,
          steps: data.reply.steps || ['Análisis completado', 'Propuesta generada'],
          chart: data.reply.chart || undefined,
          artifact: data.reply.artifact || undefined,
          approval: data.reply.approval || undefined,
          layer: 'nucleo',
        };
      }
    }
  } catch {
    // Fail silently to local fallback for maximum responsiveness
  }

  // 5. High-speed local fallback
  return respondLocally(text, attachedFiles, command, mention, viewContext);
}
