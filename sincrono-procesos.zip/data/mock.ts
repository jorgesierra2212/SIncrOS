// Datos ilustrativos divididos por dominio en data/mock/.
export * from './mock/core';
export * from './mock/skills';
export * from './mock/plugins';
export * from './mock/tasks';
export * from './mock/approvals';
export * from './mock/traces';
export * from './mock/platform';
export * from './mock/files';
export * from './mock/artifacts';
export * from './mock/agents';
export * from './mock/market';
export * from './mock/operations';
