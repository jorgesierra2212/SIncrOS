import type { RegulatoryVersion } from '../types';
import type { Conversacion, Ejecucion, Envio, EstadoEnvio, ProcesoDef, Reporte } from './types';
import { SECUENCIA_ENVIO } from './types';
import { PROCESOS } from './catalog';

const pasoPendiente = (p: ProcesoDef) =>
  p.workflow.nodes.find(n => n.data.status === 'action_required')?.data.label ?? p.workflow.nodes[p.workflow.nodes.length - 1].data.label;
const ultimoPaso = (p: ProcesoDef) => p.workflow.nodes[p.workflow.nodes.length - 1].data.label;

// ---------- Ejecuciones ----------
function ejecucionesDe(p: ProcesoDef): Ejecucion[] {
  const e = (fecha: string, estado: Ejecucion['estado'], version?: RegulatoryVersion, publicadaXM?: string): Ejecucion => ({
    id: `${p.codigo}-${fecha}${version ? '-' + version : ''}`.replace(/\s+/g, ''),
    procesoId: p.id, fecha, version, publicadaXM, estado,
    pasoActual: estado === 'Completada' ? ultimoPaso(p) : pasoPendiente(p),
    iniciadaPor: estado === 'Completada' ? 'Agente (programado)' : 'Agente (por evento)',
  });
  if (p.versionado) {
    return [
      e('Octubre 2026', 'Esperando aprobación', 'TX2', '25-oct-2026'),
      e('Octubre 2026', 'Completada', 'TX1', '21-oct-2026'),
      e('Septiembre 2026', 'Completada', 'TXR', '15-oct-2026'),
      e('Agosto 2026', 'Completada', 'TXF', '10-oct-2026'),
    ];
  }
  if (p.id === 'wf-garantias') {
    return [e('Semana 03-nov-2026', 'Esperando aprobación'), e('Semana 27-oct-2026', 'Completada'), e('Semana 20-oct-2026', 'Completada')];
  }
  if (p.dominio === 'Facturación') {
    return [e('Octubre 2026', 'Esperando aprobación'), e('Septiembre 2026', 'Completada'), e('Agosto 2026', 'Completada')];
  }
  return [
    e('26-oct-2026', 'Esperando aprobación'),
    e('25-oct-2026', 'Completada'),
    e('24-oct-2026', 'Completada'),
    e('23-oct-2026', p.id === 'wf-critica-m2c' ? 'Con error' : 'Completada'),
  ];
}
export const EJECUCIONES_INICIALES: Ejecucion[] = PROCESOS.flatMap(ejecucionesDe);

// ---------- Envíos ----------
const hist = (estados: EstadoEnvio[], base: string): Envio['historial'] =>
  estados.map((estado, i) => ({ estado, fecha: `${base} ${String(8 + i).padStart(2, '0')}:${i % 2 ? '12' : '05'}`, quien: estado === 'Aprobado' ? 'Aprobador del proceso' : 'Sistema' }));

export const ENVIOS_INICIALES: Envio[] = EJECUCIONES_INICIALES.flatMap((ej, i) => {
  const p = PROCESOS.find(x => x.id === ej.procesoId)!;
  if (!p.entidad) return [];
  const base = { id: `ENV-${2300 + i}`, procesoId: p.id, ejecucionId: ej.id, entidad: p.entidad, documento: `${p.documentoEnvio} · ${ej.fecha}${ej.version ? ' ' + ej.version : ''}`, reintentos: 0 };
  const fecha = ej.publicadaXM ?? ej.fecha;
  if (ej.estado === 'Esperando aprobación') return [{ ...base, estado: 'Preparado', historial: hist(['Preparado'], fecha) } as Envio];
  if (ej.estado === 'Con error') {
    return [{ ...base, estado: 'Rechazado', historial: hist(['Preparado', 'Aprobado', 'Enviado', 'Acuse recibido', 'Rechazado'], fecha), radicado: `XM-${88000 + i}`, motivoRechazo: 'Formato horario inválido en 2 fronteras (Frt-0533, Frt-0761).', evidencia: 'Acuse XM con código de rechazo R-204' } as Envio];
  }
  const radicado = p.entidad === 'DIAN' ? `CUFE ${(i * 7919).toString(16)}a9c…` : `XM-${88000 + i}`;
  return [{ ...base, estado: 'Aceptado', historial: hist(SECUENCIA_ENVIO, fecha), radicado, evidencia: p.entidad === 'DIAN' ? 'Acuse DIAN: documento validado' : 'Acuse XM: recibido y aceptado' } as Envio];
});

// ---------- Reportes ----------
export const REPORTES_INICIALES: Reporte[] = PROCESOS.flatMap(p => {
  const ejs = EJECUCIONES_INICIALES.filter(e => e.procesoId === p.id);
  const activa = ejs[0];
  const vivos: Reporte[] = p.plantillasReporte.map((t, k) => ({
    id: `REP-${p.codigo}-${k + 1}`, procesoId: p.id, ejecucionId: activa.id, titulo: t.titulo, tipo: t.tipo,
    estado: 'Vivo', version: 1, generadoPor: p.workflow.agentName, fecha: 'Hoy 07:40',
  }));
  const congelados: Reporte[] = ejs.filter(e => e.estado !== 'Esperando aprobación').map((e, k) => ({
    id: `REP-${p.codigo}-H${k + 1}`, procesoId: p.id, ejecucionId: e.id,
    titulo: `${p.plantillasReporte[0].titulo} · ${e.fecha}${e.version ? ' ' + e.version : ''}`,
    tipo: 'tabla', estado: 'Congelado', version: 1, generadoPor: p.workflow.agentName,
    fecha: e.publicadaXM ?? e.fecha, formato: k % 2 ? 'pdf' : 'xlsx', snapshot: p.filas,
  }));
  return [...vivos, ...congelados];
});

// ---------- Conversaciones ----------
const ejActiva = (pid: string) => EJECUCIONES_INICIALES.find(e => e.procesoId === pid)!.id;
export const CONVERSACIONES_INICIALES: Conversacion[] = [
  {
    id: 'CONV-1', dueno: 'liq', procesoId: 'wf-liq-sombra', ejecucionId: ejActiva('wf-liq-sombra'),
    titulo: 'Diferencia de reconciliación positiva en TX2', compartidaCon: [], actualizada: 'Hoy 07:52',
    mensajes: [
      { role: 'user', text: '¿Por qué difiere la reconciliación positiva de la TX2?' },
      { role: 'agent', text: 'La diferencia se concentra en las horas 18 a 21 de la Unidad 2: la generación ideal se calculó con una disponibilidad declarada anterior a la redeclaración de las 16:42. Preparé la reclamación con la regla RecPos v14 y el soporte horario.', reply: { agent: 'Auditor de liquidación', text: '', steps: ['Descargó la TX2', 'Ejecutó RecPos v14', 'Recorrió el árbol de dependencias', 'Redactó la reclamación'] } },
    ],
  },
  {
    id: 'CONV-2', dueno: 'liq', titulo: 'Embalses y precio de bolsa', compartidaCon: [], actualizada: 'Ayer 17:20',
    mensajes: [
      { role: 'user', text: '¿Cómo afecta el nivel de los embalses al precio de bolsa?' },
      { role: 'agent', text: 'La relación existe pero es débil y tiene umbral: por debajo de 45 % cada punto de embalse pesa varias veces más que por encima de 55 %.', reply: { agent: 'Analista de mercado', text: '', steps: ['Consultó bolsa y embalse', 'Calculó medianas por tramo'] } },
    ],
  },
  {
    id: 'CONV-3', dueno: 'cgm', procesoId: 'wf-critica-m2c', ejecucionId: ejActiva('wf-critica-m2c'),
    titulo: 'Desfase de reloj en Frt-0412', compartidaCon: [], actualizada: 'Hoy 05:20',
    mensajes: [
      { role: 'user', text: '¿Por qué Frt-0412 tiene desfase y cómo se estimó?' },
      { role: 'agent', text: 'El medidor principal quedó una hora atrasado desde el 18-oct. Para esas fechas se propone usar el medidor de respaldo y abrir una visita técnica.', reply: { agent: 'Crítica de medida', text: '', steps: ['Comparó principal y respaldo', 'Detectó el patrón horario'] } },
    ],
  },
  {
    id: 'CONV-4', dueno: 'fin', procesoId: 'wf-garantias', ejecucionId: ejActiva('wf-garantias'),
    titulo: 'Faltante de garantías del 3-nov', compartidaCon: ['liq'], actualizada: 'Hoy 07:10',
    mensajes: [
      { role: 'user', text: '¿Cuánto falta provisionar para la semana del 3-nov?' },
      { role: 'agent', text: 'Faltan $612 M: la proyección es de $3.418 M frente a $2.806 M provisionados, con bolsa promedio de $910/kWh.', reply: { agent: 'Proyección de garantías', text: '', steps: ['Proyectó posición', 'Calculó la garantía', 'Comparó con lo provisionado'] } },
    ],
  },
];
