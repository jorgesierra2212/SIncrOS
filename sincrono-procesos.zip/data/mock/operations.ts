import { Layer, PluginManifest, SkillFicha, TaskItem, SupportTicket, Conector, ArchivoItem, BrandConfig, ExecutionTrace, MarketDateState } from '../types';
import { seeded } from './core';
import { BOLSA, MONTHS } from './market';

// ---------- Motor de Reglas ----------
export interface FormulaNode {
  name: string;
  source?: string;
  children?: FormulaNode[];
}

export const RECPOS_TREE: FormulaNode = {
  name: 'RecPos (Reconciliación Positiva Horaria)',
  children: [
    { name: 'GenReal', source: 'Medida certificada de fronteras de generación · CGM (CREG 038)' },
    {
      name: 'GenIdeal',
      children: [
        { name: 'Despacho ideal horario', source: 'XM · Archivo de despacho ideal oficial' },
        { name: 'Disponibilidad declarada ante CND', source: 'XM · Archivo IDO (hora 16:42 redeclaración)' },
      ],
    },
    {
      name: 'PrecioRec (Precio de Reconciliación)',
      children: [
        { name: 'Precio de oferta de la unidad', source: 'XM · Ofertas horarias vigentes' },
        { name: 'Precio de bolsa spot horario', source: 'XM · Publicación FTP LAC' },
        { name: 'Costo de combustible auditado', source: 'Contratos de suministro y transporte de gas' },
      ],
    },
  ],
};

export const FORMULAS = [
  { code: 'RecPos', name: 'Reconciliación positiva', version: 14, from: '01-ene-2026', to: 'vigente', status: 'Vigente', capa: 'nucleo' as Layer },
  { code: 'RecNeg', name: 'Reconciliación negativa', version: 11, from: '01-ene-2026', to: 'vigente', status: 'Vigente', capa: 'nucleo' as Layer },
  { code: 'CxC_OEF', name: 'Cargo por confiabilidad · OEF', version: 9, from: '01-dic-2025', to: 'vigente', status: 'Vigente', capa: 'nucleo' as Layer },
  { code: 'Desv', name: 'Desviaciones de generación', version: 6, from: '01-mar-2025', to: 'vigente', status: 'Vigente', capa: 'nucleo' as Layer },
  { code: 'Restr', name: 'Restricciones de red y generación', version: 8, from: '01-jul-2025', to: 'vigente', status: 'Vigente', capa: 'nucleo' as Layer },
  { code: 'C_Cond', name: 'Contrato condicional por precio', version: 3, from: '01-feb-2026', to: 'vigente', status: 'Vigente', capa: 'enersinc_cliente' as Layer },
  { code: 'RecPos', name: 'Reconciliación positiva', version: 13, from: '01-jun-2024', to: '31-dic-2025', status: 'Histórica', capa: 'nucleo' as Layer },
  { code: 'Gar_Sem', name: 'Garantía semanal MEM', version: 2, from: '01-nov-2026', to: '—', status: 'Borrador', capa: 'enersinc_cliente' as Layer },
];

// ---------- ETRM y Contratos ----------
export const CONTRACTS = [
  { id: 'C-2026-014', cp: 'Comercializadora Andina', side: 'Venta', type: 'Pague lo contratado', from: 'ene-26', to: 'dic-28', gwh: 182.4, price: 318, index: 'IPP', asic: 'Registrado' },
  { id: 'C-2026-019', cp: 'Industrias del Caribe', side: 'Venta', type: 'Pague lo demandado', from: 'mar-26', to: 'feb-27', gwh: 46.1, price: 342, index: 'IPC', asic: 'Registrado' },
  { id: 'C-2026-031', cp: 'Energía Sabana', side: 'Venta', type: 'Condicional por precio de bolsa', from: 'jul-26', to: 'jun-27', gwh: 58.3, price: 365, index: 'Bolsa', asic: 'Registrado' },
  { id: 'C-2025-077', cp: 'Generadora del Sinú', side: 'Compra', type: 'Pague lo contratado', from: 'ene-25', to: 'dic-27', gwh: 96.0, price: 295, index: 'IPP', asic: 'Registrado' },
  { id: 'C-2026-042', cp: 'Solar Cesar', side: 'Compra', type: 'PPA renovable', from: 'ene-27', to: 'dic-38', gwh: 210.0, price: 247, index: 'IPC', asic: 'Pendiente' },
  { id: 'SICEP-26-08', cp: 'Convocatoria SICEP', side: 'Venta', type: 'Estandarizado SICEP', from: 'ene-27', to: 'dic-29', gwh: 120.0, price: 334, index: 'IPP', asic: 'En adjudicación' },
];

export const POSITION = Array.from({ length: 30 }, (_, d) => {
  const r = seeded(100 + d);
  const gen = 820 + r() * 260 - (d > 18 ? 180 : 0);
  const compras = 260;
  const ventas = 1080 + r() * 40;
  return { dia: `${d + 1}`, generacion: Math.round(gen), compras, ventas: Math.round(ventas), neta: Math.round(gen + compras - ventas) };
});

export const MTM = CONTRACTS.map((c, i) => {
  const curve = [355, 348, 360, 340, 300, 338][i];
  const sign = c.side === 'Venta' ? 1 : -1;
  return { ...c, curve, mtm: Math.round(sign * (c.price - curve) * c.gwh * 1_000_000 * 0.35) };
});

export const SICEP_CALLS = [
  { id: 'SICEP-26-08', buyer: 'Comercializador regulado A', product: 'Anual plano', period: '2027–2029', gwh: 640, close: '06-nov-2026', status: 'Abierta' },
  { id: 'SICEP-26-09', buyer: 'Comercializador regulado B', product: 'Base + punta', period: '2027–2028', gwh: 310, close: '13-nov-2026', status: 'Abierta' },
  { id: 'SICEP-26-05', buyer: 'Comercializador regulado C', product: 'Anual plano', period: '2027', gwh: 180, close: '02-oct-2026', status: 'Adjudicada' },
];

// ---------- Riesgo y Escenarios ----------
export const SCENARIOS = MONTHS.slice(-6).concat(['nov-26', 'dic-26', 'ene-27', 'feb-27', 'mar-27', 'abr-27']).map((m, i) => ({
  mes: m,
  real: i < 6 ? BOLSA[16 + i] : undefined,
  humedo: i >= 5 ? Math.round(690 - (i - 5) * 70) : undefined,
  medio: i >= 5 ? Math.round(690 - (i - 5) * 25) : undefined,
  seco: i >= 5 ? Math.round(690 + (i - 5) * 60) : undefined,
}));

export const LIMITS = [
  { name: 'Exposición a bolsa de la demanda atendida', use: 21, limit: 25, unit: '%' },
  { name: 'Pérdida en riesgo (PaR 95 %, 30 días)', use: 3.9, limit: 5, unit: 'mil M' },
  { name: 'Concentración en una contraparte', use: 38, limit: 40, unit: '%' },
  { name: 'Garantías sobre caja disponible', use: 62, limit: 70, unit: '%' },
];

export const GUARANTEES = ['27-oct', '03-nov', '10-nov', '17-nov', '24-nov', '01-dic'].map((w, i) => ({
  semana: w,
  proyectada: [2.95, 3.42, 3.31, 3.05, 2.88, 2.71][i],
  xm: i === 0 ? 2.91 : undefined,
  provisionada: 2.81,
}));

// ---------- Facturación y Usuarios ----------
export const INVOICES = [
  { n: 'FE-23891', client: 'Industrias del Caribe', concept: 'Energía octubre', value: 412_800_000, state: 'Por aprobar', dian: '—', erp: '—', cufe: '—', fecha: '25-oct-2026' },
  { n: 'FE-23890', client: 'Comercializadora Andina', concept: 'Contrato C-2026-014', value: 1_284_000_000, state: 'Por aprobar', dian: '—', erp: '—', cufe: '—', fecha: '25-oct-2026' },
  { n: 'FE-23874', client: 'Sede Montería 2', concept: 'Energía septiembre', value: 38_400_000, state: 'Registrada', dian: 'Aceptada', erp: 'Sincronizada', cufe: '9a7f3c...b281', fecha: '30-sep-2026' },
  { n: 'FE-23873', client: 'Energía Sabana', concept: 'Contrato C-2026-031', value: 642_100_000, state: 'Registrada', dian: 'Aceptada', erp: 'Sincronizada', cufe: '4d8a1e...c992', fecha: '30-sep-2026' },
  { n: 'FE-23866', client: 'Sede Cali 1', concept: 'Excedentes AGR', value: 9_850_000, state: 'Con errores', dian: 'Rechazada: NIT', erp: 'Fallo VPN (TK-802)', cufe: '—', fecha: '05-oct-2026' },
  { n: 'FE-23860', client: 'Planta Barranquilla 1', concept: 'Respaldo de contratos', value: 220_300_000, state: 'En proceso', dian: 'Enviada', erp: 'Pendiente', cufe: 'e71b90...aa14', fecha: '05-oct-2026' },
];

export const CREDIT_NOTES = [
  { n: 'NC-0412', refFactura: 'FE-23874', client: 'Sede Montería 2', valor: 3_840_000, motivo: 'Ajuste de lectura de medidor por informe de crítica', fecha: '04-oct-2026', estado: 'Aprobada' },
  { n: 'NC-0413', refFactura: 'FE-23873', client: 'Energía Sabana', valor: 10_360_000, motivo: 'Reliquidación versión TX2 concepto restricciones', fecha: '12-oct-2026', estado: 'Aprobada' },
];

export const END_USERS = [
  { user: 'Sede Bogotá 1', market: 'No regulado', kwh: 812_400, G: 318, T: 48, D: 96, C: 22, P: 31, R: 19 },
  { user: 'Sede Medellín 2', market: 'No regulado', kwh: 402_100, G: 325, T: 48, D: 102, C: 22, P: 31, R: 19 },
  { user: 'Sede Cali 1', market: 'Autogeneración remota', kwh: 96_700, G: 280, T: 48, D: 118, C: 25, P: 33, R: 19 },
  { user: 'Sede Montería 2', market: 'Regulado', kwh: 41_300, G: 342, T: 48, D: 164, C: 61, P: 44, R: 19 },
  { user: 'Sede Cartagena 3', market: 'No regulado', kwh: 655_900, G: 311, T: 48, D: 89, C: 20, P: 29, R: 19 },
];

// ---------- Despacho y Plantas ----------
export const PLANTS = [
  { name: 'Planta térmica Norte · U1', tech: 'Térmica gas', cap: 160, disp: 155, desp: 150, real: 149.2, state: 'En despacho' },
  { name: 'Planta térmica Norte · U2', tech: 'Térmica gas', cap: 160, disp: 120, desp: 140, real: 118.4, state: 'Desviación' },
  { name: 'Hidro Sinú', tech: 'Hidráulica', cap: 340, disp: 330, desp: 210, real: 211.0, state: 'En despacho' },
  { name: 'Solar Cesar', tech: 'Solar', cap: 90, disp: 90, desp: 61, real: 58.7, state: 'Variable' },
];

export const PLANT_DAY = Array.from({ length: 24 }, (_, h) => ({
  hora: `${h}`,
  despacho: h >= 17 && h <= 21 ? 140 : h >= 8 ? 120 : 90,
  real: h >= 17 && h <= 21 ? 118 : h >= 8 ? 119 : 89,
  disponibilidad: h >= 16 ? 120 : 155,
}));

export const DESPACHO_OFERTAS_DATA = [
  { planta: 'Térmica Norte U1', tech: 'Gas CC', capMax: 160, precioOferta: 345.5, dispDeclarada: 155, minTecnico: 60, rampaSubida: 2.5, estado: 'Enviada CND' },
  { planta: 'Térmica Norte U2', tech: 'Gas CC', capMax: 160, precioOferta: 360.0, dispDeclarada: 120, minTecnico: 60, rampaSubida: 2.5, estado: 'Redeclarada 16:42' },
  { planta: 'Hidro Sinú', tech: 'Hidráulica embalse', capMax: 340, precioOferta: 215.0, dispDeclarada: 330, minTecnico: 40, rampaSubida: 15.0, estado: 'Enviada CND' },
  { planta: 'Solar Cesar', tech: 'Solar Fotovoltaica', capMax: 90, precioOferta: 0.0, dispDeclarada: 90, minTecnico: 0, rampaSubida: 30.0, estado: 'Enviada CND' },
];

export const REDESPACHOS_DATA = [
  { hora: '16:45', unidad: 'Térmica Norte U2', tipo: 'Seguridad de área', solicitante: 'CND XM', anteriorMW: 140, nuevoMW: 118, motivo: 'Restricción en línea Ternera-Candelaria 230kV', compensacion: 'Reconciliación positiva reconocida' },
  { hora: '11:15', unidad: 'Hidro Sinú', tipo: 'Control de frecuencia', solicitante: 'CND XM', anteriorMW: 200, nuevoMW: 220, motivo: 'Reserva rodante secundaria AGC', compensacion: 'Servicios complementarios' },
];

// ---------- Auditoría Inmutable ----------
export interface AuditRecord {
  when: string;
  who: string;
  what: string;
  version: string;
  capa: Layer;
  ip?: string;
}

export const AUDIT_INITIAL: AuditRecord[] = [
  { when: 'Hoy 10:45', who: 'Agente · Crítica de medida', what: 'Ejecutó sondeo automático de comunicaciones de 1.284 fronteras (Nivel 3)', version: 'sk-cgm-01 v2', capa: 'nucleo', ip: '10.200.0.4' },
  { when: 'Hoy 08:35', who: 'Agente · Cargos y facturación', what: 'Detectó fallo en conector ERP SAP y generó ticket TK-802 (Nivel 2)', version: 'sk-fac-06 v1', capa: 'enersinc_cliente', ip: '10.200.0.12' },
  { when: 'Hoy 08:02', who: 'Agente · Reporte SRM', what: 'Generó ART-118 y envió solicitud de aprobación A-1043 a Laura Méndez', version: 'sk-cgm-04 v3', capa: 'nucleo', ip: '10.200.0.8' },
  { when: 'Hoy 07:40', who: 'Agente · Auditor de liquidación', what: 'Preparó reclamación formal ART-104 (v2) y creó aprobación A-1042', version: 'RecPos v14', capa: 'nucleo', ip: '10.200.0.10' },
  { when: 'Hoy 07:31', who: 'Agente · Auditor de liquidación', what: 'Comparó TX2 de 21-oct: detectó 3 diferencias sobre umbral ($48,4 M en RecPos)', version: 'sk-liq-03 v4', capa: 'nucleo', ip: '10.200.0.10' },
  { when: 'Ayer 18:10', who: 'Andrés Rojas (Liquidación)', what: 'Aprobó corrección de despacho contrato condicional C-2026-019', version: 'Contrato v2.1', capa: 'cliente', ip: '190.144.22.18' },
  { when: 'Ayer 16:02', who: 'Gerencia comercial', what: 'Elevó nivel de autonomía de Mesa de ayuda a Nivel 3 (autónomo)', version: 'Admin v1', capa: 'cliente', ip: '190.144.22.10' },
  { when: '23-oct 11:20', who: 'Carlos Varela (Admin)', what: 'Configuró conector XM SRM API con token JWT renovado', version: 'Conector v4', capa: 'nucleo', ip: '190.144.22.15' },
];

export const ROLES_MATRIX = [
  { action: 'Enviar archivo al SRM (XM)', cgm: 'Aprueba', liq: '—', fin: '—', ger: 'Ve', admin: 'Configura', agente: 'Ejecuta (N2)' },
  { action: 'Radicar reclamación ante el ASIC', cgm: '—', liq: 'Aprueba', fin: '—', ger: 'Ve', admin: 'Ve', agente: 'Prepara (N1)' },
  { action: 'Emitir facturas y enviar al ERP', cgm: '—', liq: '—', fin: 'Aprueba', ger: 'Ve', admin: 'Ve', agente: 'Prepara (N2)' },
  { action: 'Cambiar regla del motor (CREG)', cgm: '—', liq: 'Propone', fin: '—', ger: 'Aprueba', admin: 'Audita', agente: '—' },
  { action: 'Crear / Editar plugins cliente', cgm: 'Propone', liq: 'Propone', fin: 'Propone', ger: 'Ve', admin: 'Aprueba', agente: 'Prueba (Auto)' },
  { action: 'Subir nivel de autonomía agente', cgm: 'Propone', liq: 'Propone', fin: 'Propone', ger: 'Aprueba', admin: 'Aplica', agente: '—' },
  { action: 'Personalizar marca blanca', cgm: '—', liq: '—', fin: '—', ger: 'Aprueba', admin: 'Aplica', agente: '—' },
];

export const MODELS = [
  { task: 'Conversación y explicación en lenguaje natural', model: 'Modelo configurado (servidor)', why: 'Velocidad, fluidez en español de Colombia y citación de normas CREG', provider: 'Google AI Studio' },
  { task: 'Traducción a SQL sobre BigQuery Lake', model: 'Modelo configurado (servidor)', why: 'Costo-eficiencia y generación de esquemas analíticos', provider: 'Google AI Studio' },
  { task: 'Revisión y razonamiento de discrepancias TX', model: 'Modelo configurado con árbol de dependencias', why: 'Trazabilidad y no alucinación de montos', provider: 'Google AI Studio' },
];
