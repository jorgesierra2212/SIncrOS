import { Layer, PluginManifest, SkillFicha, TaskItem, SupportTicket, Conector, ArchivoItem, BrandConfig, ExecutionTrace, MarketDateState } from '../types';

// Todos los datos de este archivo son ILUSTRATIVOS para el mockup de Enersinc OS.
// En producción provienen del núcleo de datos (BigQuery) y del motor de reglas.


export type ViewId =
  | 'inicio' | 'bandeja' | 'conversacion' | 'agentes' | 'tareas' | 'procesos' | 'artefactos'
  | 'despacho_ofertas' | 'despacho_prog_real' | 'despacho_redespacho' | 'despacho_intradiario'
  | 'liquidacion' | 'motor' | 'garantias' | 'reclamaciones'
  | 'facturacion' | 'facturas_dian' | 'notas_credito' | 'envio_erp' | 'usuarios'
  | 'fronteras' | 'critica' | 'srm' | 'aenc' | 'informe_anual'
  | 'contratos' | 'posicion' | 'sicep' | 'riesgo' | 'escenarios'
  | 'supervision' | 'mercado'
  | 'plugins' | 'integraciones' | 'archivos' | 'soporte' | 'admin'
  | 'proceso' | 'mis_conversaciones' | 'equipos';

export type Group = 'Trabajo' | 'Despacho' | 'Liquidación' | 'Facturación' | 'CGM / Medida' | 'ETRM y riesgo' | 'Operación y mercado' | 'Plataforma';

export type ViewType = 'trabajo' | 'proceso' | 'tablero' | 'configuracion';

export const VIEWS: Record<ViewId, { label: string; group: Group; desc: string; capa: Layer; tipo: ViewType }> = {
  inicio: { label: 'Centro de mando MEM', group: 'Trabajo', desc: 'Resumen ejecutivo, estado del mercado, aprobaciones urgentes y ciclo del día.', capa: 'nucleo', tipo: 'trabajo' },
  bandeja: { label: 'Mi bandeja', group: 'Trabajo', desc: 'Lo que los agentes ejecutaron y espera su revisión humana.', capa: 'nucleo', tipo: 'trabajo' },
  conversacion: { label: 'Conversación', group: 'Trabajo', desc: 'Pregunte, comande con / o mencione @agentes para ejecutar tareas.', capa: 'nucleo', tipo: 'trabajo' },
  agentes: { label: 'Agentes y skills', group: 'Trabajo', desc: 'Procedimientos, niveles de autonomía y desempeño de cada agente.', capa: 'nucleo', tipo: 'trabajo' },
  tareas: { label: 'Tareas programadas', group: 'Trabajo', desc: 'Ejecuciones automáticas por horario cron o eventos de mercado.', capa: 'nucleo', tipo: 'trabajo' },
  procesos: { label: 'Mapa de procesos', group: 'Trabajo', desc: 'Ciclo comercial integral y grado de automatización por etapa.', capa: 'nucleo', tipo: 'trabajo' },
  artefactos: { label: 'Artefactos', group: 'Trabajo', desc: 'Tablas, reportes, modelos, gráficos y fórmulas versionadas.', capa: 'nucleo', tipo: 'trabajo' },

  despacho_ofertas: { label: 'Ofertas y declaraciones', group: 'Despacho', desc: 'Precio de oferta horario y disponibilidad declarada por planta ante el CND.', capa: 'enersinc_cliente', tipo: 'proceso' },
  despacho_prog_real: { label: 'Despacho programado vs real', group: 'Despacho', desc: 'Seguimiento horario de generación real contra despacho programado e ideal.', capa: 'enersinc_cliente', tipo: 'tablero' },
  despacho_redespacho: { label: 'Redespacho y restricciones', group: 'Despacho', desc: 'Redespachos ordenados por seguridad de red o restricciones de combustible.', capa: 'enersinc_cliente', tipo: 'proceso' },
  despacho_intradiario: { label: 'Mercado intradiario', group: 'Despacho', desc: 'Ajuste de posiciones en ventanas continuas de negociación horaria (preparada).', capa: 'enersinc_cliente', tipo: 'tablero' },

  liquidacion: { label: 'Liquidación sombra', group: 'Liquidación', desc: 'Cálculo paralelo de cada concepto (TX1 a TXF) contra publicaciones de XM.', capa: 'nucleo', tipo: 'proceso' },
  motor: { label: 'Motor de reglas', group: 'Liquidación', desc: 'Fórmulas versionadas por vigencia CREG, árbol de dependencias y pruebas.', capa: 'nucleo', tipo: 'tablero' },
  garantias: { label: 'Garantías y aportes', group: 'Liquidación', desc: 'Obligaciones proyectadas ante el mercado y calendario de aportes.', capa: 'enersinc_cliente', tipo: 'proceso' },
  reclamaciones: { label: 'Reclamaciones ASIC', group: 'Liquidación', desc: 'Expedientes de reclamación formal ante el ASIC con soporte y cálculo horario.', capa: 'enersinc_cliente', tipo: 'proceso' },

  facturacion: { label: 'Prefacturas y cargos', group: 'Facturación', desc: 'Matriz de consumos, cargos regulados y generación de prefacturas.', capa: 'enersinc_cliente', tipo: 'proceso' },
  facturas_dian: { label: 'Facturas electrónicas DIAN', group: 'Facturación', desc: 'Emisión, validación previa DIAN y estado CUFE de cada factura.', capa: 'enersinc_cliente', tipo: 'proceso' },
  notas_credito: { label: 'Notas crédito', group: 'Facturación', desc: 'Ajustes por reliquidación comercial o corrección de medidas.', capa: 'enersinc_cliente', tipo: 'proceso' },
  envio_erp: { label: 'Envío al ERP', group: 'Facturación', desc: 'Sincronización de hechos económicos hacia SAP, Oracle o ERP corporativo.', capa: 'enersinc_cliente', tipo: 'proceso' },
  usuarios: { label: 'Tarifa usuarios finales', group: 'Facturación', desc: 'Desagregación de la tarifa por componentes CU (G, T, D, C, P, R).', capa: 'enersinc_cliente', tipo: 'tablero' },

  fronteras: { label: 'Fronteras y medida (MDM)', group: 'CGM / Medida', desc: 'Estado de comunicación, lecturas y hoja de vida de cada frontera comercial.', capa: 'nucleo', tipo: 'tablero' },
  critica: { label: 'Crítica de medida', group: 'CGM / Medida', desc: 'Detección de faltantes, desfases, lecturas anómalas y estimaciones según regla.', capa: 'nucleo', tipo: 'proceso' },
  srm: { label: 'Reporte SRM', group: 'CGM / Medida', desc: 'Generación, validación de formato y transmisión de archivos al SRM de XM.', capa: 'nucleo', tipo: 'proceso' },
  aenc: { label: 'Auditoría AENC', group: 'CGM / Medida', desc: 'Cruce tripartito: telemedida vs lo reportado al SRM vs liquidado por XM.', capa: 'enersinc_cliente', tipo: 'proceso' },
  informe_anual: { label: 'Informe anual de fronteras', group: 'CGM / Medida', desc: 'Consolidado anual de calidad de la medida y calibración de transformadores.', capa: 'enersinc_cliente', tipo: 'proceso' },

  contratos: { label: 'Libro de contratos', group: 'ETRM y riesgo', desc: 'Contratos bilaterales, compras/ventas, indexaciones y registro ASIC.', capa: 'enersinc_cliente', tipo: 'tablero' },
  posicion: { label: 'Posición y MtM', group: 'ETRM y riesgo', desc: 'Posición neta horaria y valoración a mercado contra la curva de precios.', capa: 'enersinc_cliente', tipo: 'tablero' },
  sicep: { label: 'SICEP Convocatorias', group: 'ETRM y riesgo', desc: 'Convocatorias públicas estandarizadas de largo plazo y ofertas del agente.', capa: 'enersinc_cliente', tipo: 'tablero' },
  riesgo: { label: 'Exposición y PaR', group: 'ETRM y riesgo', desc: 'Exposición de la demanda a bolsa y pérdida en riesgo ante límites.', capa: 'enersinc_cliente', tipo: 'tablero' },
  escenarios: { label: 'Escenarios hidrológicos', group: 'ETRM y riesgo', desc: 'Sensibilidad ante hidrología seca, media y húmeda en el SIN.', capa: 'enersinc_cliente', tipo: 'tablero' },

  supervision: { label: 'Supervisión de plantas', group: 'Operación y mercado', desc: 'Monitoreo de generación real y disponibilidad en tiempo real (solo lectura).', capa: 'nucleo', tipo: 'tablero' },
  mercado: { label: 'Bolsa e hidrología', group: 'Operación y mercado', desc: 'Precio de bolsa spot, embalse agregado del SIN y recurso marginal.', capa: 'nucleo', tipo: 'tablero' },

  plugins: { label: 'Plugins y catálogo', group: 'Plataforma', desc: 'Estudio de creación, casos de prueba, sandbox y promoción de plugins.', capa: 'cliente', tipo: 'configuracion' },
  integraciones: { label: 'Integraciones y conectores', group: 'Plataforma', desc: 'Catálogo de conectores (XM, BigQuery, ERP, MDM, SCADA) con asistente.', capa: 'nucleo', tipo: 'configuracion' },
  archivos: { label: 'Archivos y datos', group: 'Plataforma', desc: 'Carga de Excel, PDF, PPT, visor interactivo y exportación de reportes.', capa: 'nucleo', tipo: 'configuracion' },
  soporte: { label: 'Soporte y respaldo manual', group: 'Plataforma', desc: 'Gestión de tickets por fallas de tareas automáticas y escalamiento Enersinc.', capa: 'nucleo', tipo: 'configuracion' },
  proceso: { label: 'Proceso', group: 'Trabajo', desc: 'Espacio de trabajo del proceso con sus siete componentes.', capa: 'nucleo', tipo: 'proceso' },
  mis_conversaciones: { label: 'Mis conversaciones', group: 'Trabajo', desc: 'Conversaciones propias y compartidas, ligadas a procesos y ejecuciones.', capa: 'nucleo', tipo: 'trabajo' },
  equipos: { label: 'Equipos', group: 'Plataforma', desc: 'Miembros, roles por proceso y procesos compartidos.', capa: 'nucleo', tipo: 'configuracion' },
  admin: { label: 'Administración', group: 'Plataforma', desc: 'Marca blanca en vivo, matriz de roles, modelos de IA por tarea y auditoría.', capa: 'nucleo', tipo: 'configuracion' },
};

export const GROUP_ORDER: Group[] = [
  'Trabajo',
  'Despacho',
  'Liquidación',
  'Facturación',
  'CGM / Medida',
  'ETRM y riesgo',
  'Operación y mercado',
  'Plataforma',
];

export interface Profile {
  id: string;
  person: string;
  role: string;
  initials: string;
  home: ViewId;
  views: ViewId[];
  pinned: string[];
  capa: Layer;
}

export const PROFILES: Profile[] = [
  {
    id: 'cgm',
    person: 'Laura Méndez',
    role: 'Operadora CGM',
    initials: 'LM',
    home: 'bandeja',
    capa: 'cliente',
    views: ['bandeja', 'conversacion', 'agentes', 'tareas', 'fronteras', 'critica', 'srm', 'aenc', 'informe_anual', 'supervision', 'archivos', 'artefactos'],
    pinned: ['ART-118', 'ART-121'],
  },
  {
    id: 'liq',
    person: 'Andrés Rojas',
    role: 'Analista de liquidación',
    initials: 'AR',
    home: 'bandeja',
    capa: 'cliente',
    views: ['bandeja', 'conversacion', 'liquidacion', 'motor', 'reclamaciones', 'garantias', 'aenc', 'contratos', 'procesos', 'archivos', 'artefactos'],
    pinned: ['ART-104', 'ART-110'],
  },
  {
    id: 'despacho',
    person: 'Camila Ortiz',
    role: 'Analista de despacho y mercado',
    initials: 'CO',
    home: 'bandeja',
    capa: 'cliente',
    views: ['despacho_ofertas', 'despacho_prog_real', 'despacho_redespacho', 'despacho_intradiario', 'mercado', 'supervision', 'posicion', 'sicep', 'contratos', 'riesgo', 'conversacion', 'artefactos'],
    pinned: ['ART-101', 'ART-112'],
  },
  {
    id: 'fin',
    person: 'Diana Pérez',
    role: 'Finanzas y facturación',
    initials: 'DP',
    home: 'bandeja',
    capa: 'cliente',
    views: ['bandeja', 'conversacion', 'facturacion', 'facturas_dian', 'notas_credito', 'envio_erp', 'usuarios', 'garantias', 'archivos', 'artefactos'],
    pinned: ['ART-110', 'ART-115'],
  },
  {
    id: 'ger',
    person: 'Gerencia Comercial',
    role: 'Gerencia',
    initials: 'GC',
    home: 'bandeja',
    capa: 'cliente',
    views: ['inicio', 'bandeja', 'conversacion', 'riesgo', 'escenarios', 'liquidacion', 'despacho_prog_real', 'mercado', 'artefactos'],
    pinned: ['ART-101', 'ART-104'],
  },
  {
    id: 'admin_cliente',
    person: 'Carlos Varela',
    role: 'Administrador del cliente',
    initials: 'CV',
    home: 'bandeja',
    capa: 'cliente',
    views: ['admin', 'plugins', 'integraciones', 'tareas', 'procesos', 'soporte', 'archivos', 'agentes', 'artefactos'],
    pinned: [],
  },
  {
    id: 'enersinc',
    person: 'Martín Gómez',
    role: 'Enersinc (soporte y certificación)',
    initials: 'EN',
    home: 'bandeja',
    capa: 'nucleo',
    views: ['soporte', 'admin', 'plugins', 'motor', 'integraciones', 'liquidacion', 'srm', 'tareas', 'agentes', 'artefactos'],
    pinned: ['ART-125', 'ART-130'],
  },
];

// Helper functions
export function seeded(seed: number) {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

export const cop = (n: number) => {
  const a = Math.abs(n);
  const s = n < 0 ? '−' : '';
  if (a >= 1e9) return `${s}$${(a / 1e9).toLocaleString('es-CO', { maximumFractionDigits: 2 })} mil M`;
  if (a >= 1e6) return `${s}$${(a / 1e6).toLocaleString('es-CO', { maximumFractionDigits: 1 })} M`;
  return `${s}$${a.toLocaleString('es-CO', { maximumFractionDigits: 0 })}`;
};

export const num = (n: number, d = 0) => n.toLocaleString('es-CO', { maximumFractionDigits: d, minimumFractionDigits: d });
