import { Layer, PluginManifest, SkillFicha, TaskItem, SupportTicket, Conector, ArchivoItem, BrandConfig, ExecutionTrace, MarketDateState } from '../types';
import { seeded } from './core';

// ---------- Series de Mercado ----------
export const MONTHS = ['ene-25', 'feb-25', 'mar-25', 'abr-25', 'may-25', 'jun-25', 'jul-25', 'ago-25', 'sep-25', 'oct-25', 'nov-25', 'dic-25', 'ene-26', 'feb-26', 'mar-26', 'abr-26', 'may-26', 'jun-26', 'jul-26', 'ago-26', 'sep-26', 'oct-26'];
export const BOLSA = [530, 430, 215, 140, 120, 110, 120, 210, 300, 150, 180, 280, 210, 105, 190, 240, 490, 560, 800, 946, 905, 690];
export const EMBALSE = [62, 55, 48, 52, 63, 71, 78, 80, 76, 74, 77, 72, 64, 56, 50, 55, 66, 74, 79, 79, 71, 64];
export const HIDRO = [5100, 4900, 5700, 5600, 6000, 5650, 6050, 5900, 5650, 6050, 5750, 5900, 5900, 5400, 5750, 5600, 5600, 5200, 5100, 4800, 4500, 4700];
export const TERMO = [1500, 1100, 800, 750, 700, 750, 760, 850, 950, 700, 800, 900, 800, 600, 1000, 1000, 1400, 1500, 1900, 2250, 2443, 2100];
export const MARKET = MONTHS.map((m, i) => ({ mes: m, bolsa: BOLSA[i], embalse: EMBALSE[i], hidraulica: HIDRO[i], termica: TERMO[i], escasez: 1172 }));

export const EMBALSE_TRAMOS = [
  { tramo: '30–40 %', precio: 338 },
  { tramo: '40–50 %', precio: 220 },
  { tramo: '50–60 %', precio: 220 },
  { tramo: '60–70 %', precio: 232 },
  { tramo: '70–80 %', precio: 150 },
  { tramo: '80–90 %', precio: 129 },
];

// ---------- Fronteras de Medida ----------
export const BRANDS = ['Itron', 'Elster', 'ION', 'SEL'];
export const TYPES = ['Generación', 'Consumo no regulado', 'Autogeneración remota', 'Consumo regulado', 'Excedentes'];
export const PLACES = ['Barranquilla', 'Montería', 'Cartagena', 'Valledupar', 'Medellín', 'Bogotá', 'Cali', 'Bucaramanga', 'Santa Marta', 'Sincelejo'];
export interface Frontier {
  code: string;
  name: string;
  type: string;
  brand: string;
  com: 'OK' | 'Alerta' | 'Caída';
  lastRead: string;
  critica: 'OK' | 'Alerta' | 'Error';
  kwh: number;
}

export const FRONTIERS: Frontier[] = (() => {
  const r = seeded(7);
  return Array.from({ length: 28 }, (_, i) => {
    const x = r();
    const com = x > 0.93 ? 'Caída' : x > 0.84 ? 'Alerta' : 'OK';
    const y = r();
    const critica = i === 3 ? 'Error' : y > 0.9 ? 'Error' : y > 0.78 ? 'Alerta' : 'OK';
    return {
      code: i === 3 ? 'Frt-0412' : `Frt-${String(100 + Math.floor(r() * 900)).padStart(4, '0')}`,
      name: `${TYPES[i % TYPES.length] === 'Generación' ? 'Planta' : 'Sede'} ${PLACES[i % PLACES.length]} ${1 + (i % 3)}`,
      type: TYPES[i % TYPES.length],
      brand: BRANDS[Math.floor(r() * 4)],
      com: com as Frontier['com'],
      lastRead: com === 'Caída' ? 'Hace 7 h' : `Hace ${5 + Math.floor(r() * 50)} min`,
      critica: critica as Frontier['critica'],
      kwh: Math.round(2000 + r() * 90000),
    };
  });
})();

export const HOURLY_ANOMALY = Array.from({ length: 24 }, (_, h) => {
  const base = 380 + 260 * Math.sin(((h - 6) / 24) * Math.PI * 2) + (h > 8 && h < 18 ? 120 : 0);
  const prev = 380 + 260 * Math.sin(((h - 7) / 24) * Math.PI * 2) + (h > 9 && h < 19 ? 120 : 0);
  return { hora: `${h}`, respaldo: Math.round(base), principal: Math.round(prev) };
});

// ---------- Liquidación Sombra ----------
export const SETTLEMENT = [
  { concepto: 'Ventas en bolsa', calc: 18_420_300_000, xm: 18_419_900_000 },
  { concepto: 'Compras en bolsa', calc: -6_210_450_000, xm: -6_210_450_000 },
  { concepto: 'Reconciliación positiva', calc: 1_332_850_000, xm: 1_284_500_000 },
  { concepto: 'Reconciliación negativa', calc: -412_300_000, xm: -412_300_000 },
  { concepto: 'Restricciones', calc: -288_900_000, xm: -301_750_000 },
  { concepto: 'Cargo por confiabilidad', calc: 4_870_000_000, xm: 4_870_000_000 },
  { concepto: 'Desviaciones', calc: -96_400_000, xm: -96_380_000 },
  { concepto: 'Contratos despachados', calc: 9_840_000_000, xm: 9_840_000_000 },
  { concepto: 'Servicios CND y ASIC', calc: -38_200_000, xm: -38_200_000 },
  { concepto: 'Combustibles reconocidos', calc: 2_115_000_000, xm: 2_089_600_000 },
];
export const VERSIONS = ['TX1', 'TX2', 'TX3', 'TXR', 'TXF'];
