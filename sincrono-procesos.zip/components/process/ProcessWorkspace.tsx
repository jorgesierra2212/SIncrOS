import React from 'react';
import { Plus, User, Clock, Building2 } from 'lucide-react';
import { useProcess } from './ProcessStore';
import { Badge, Btn, StatusBadge } from '../ui';
import { PESTANAS } from '../../data/process/types';
import type { ProcesoDef } from '../../data/process/types';
import FlujoTab from './tabs/FlujoTab';
import DatosTab from './tabs/DatosTab';
import ChatTab from './tabs/ChatTab';
import ReportesTab from './tabs/ReportesTab';
import FechasTab from './tabs/FechasTab';
import EnviosTab from './tabs/EnviosTab';
import HistoricoTab from './tabs/HistoricoTab';

const ROL_TONO = { Dueño: 'brand', Aprobador: 'ok', Ejecutor: 'warn', Lector: 'neutral' } as const;

export default function ProcessWorkspace({ p }: { p: ProcesoDef }) {
  const { pestana, setPestana, ejecuciones, ejecucionActiva, seleccionarEjecucion, nuevaEjecucion, rol, puede, envios, reportes } = useProcess();
  const ej = ejecucionActiva(p.id);
  const lista = ejecuciones.filter(e => e.procesoId === p.id);
  const miRol = rol(p.id);
  const etiqueta = (e: typeof ej) => (p.versionado ? `${e.fecha} · ${e.version}` : e.fecha);

  const contadores: Partial<Record<string, number>> = {
    envios: envios.filter(e => e.procesoId === p.id && e.ejecucionId === ej.id && ['Preparado', 'Rechazado'].includes(e.estado)).length,
    reportes: reportes.filter(r => r.procesoId === p.id && r.ejecucionId === ej.id && r.estado !== 'Congelado').length,
  };

  const Contenido = { flujo: FlujoTab, datos: DatosTab, chat: ChatTab, reportes: ReportesTab, fechas: FechasTab, envios: EnviosTab, historico: HistoricoTab }[pestana];

  return (
    <div>
      <div className="bg-white border border-line rounded-lg px-4 py-3 mb-3">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-xs text-mut">
              <span className="font-mono text-brand bg-brandsoft rounded px-1.5 py-0.5">{p.codigo}</span>
              <span>{p.dominio}</span>
              {p.entidad && <span className="inline-flex items-center gap-1"><Building2 size={11} /> {p.entidad}</span>}
            </div>
            <h1 className="text-xl font-semibold leading-tight mt-0.5">{p.nombre}</h1>
          </div>
          <div className="flex flex-wrap items-center gap-2 ml-auto">
            <label className="text-sm">
              <span className="sr-only">{p.versionado ? 'Periodo y versión' : 'Fecha de operación'}</span>
              <select value={ej.id} onChange={e => seleccionarEjecucion(p.id, e.target.value)} className="border border-line rounded-md px-2.5 py-1.5 bg-white font-medium">
                {lista.map(e => <option key={e.id} value={e.id}>{etiqueta(e)}</option>)}
              </select>
            </label>
            <StatusBadge s={ej.estado} />
            {puede(p.id).configurar || puede(p.id).ejecutar ? (
              <Btn small onClick={() => nuevaEjecucion(p.id)}><Plus size={13} /> Nueva ejecución</Btn>
            ) : null}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-xs text-mut">
          <span className="inline-flex items-center gap-1"><Clock size={12} /> Paso actual: <b className="text-txt font-medium">{ej.pasoActual}</b></span>
          <span className="inline-flex items-center gap-1"><User size={12} /> Su rol: <Badge tone={ROL_TONO[miRol]}>{miRol}</Badge></span>
          <span>Iniciada por {ej.iniciadaPor}</span>
          {ej.publicadaXM && <span>Publicada por XM: {ej.publicadaXM}</span>}
        </div>
      </div>

      <div className="flex gap-1 border-b border-line mb-4 overflow-x-auto" role="tablist">
        {PESTANAS.map((t, i) => (
          <button key={t.id} role="tab" aria-selected={pestana === t.id} onClick={() => setPestana(t.id)}
            className={`px-3.5 py-2 text-sm whitespace-nowrap border-b-2 -mb-px ${pestana === t.id ? 'border-brand text-brand font-semibold' : 'border-transparent text-mut hover:text-txt'}`}>
            <span className="text-[11px] text-mut mr-1">{i + 1}</span>{p.versionado || t.id !== 'fechas' ? t.label : 'Fechas'}
            {contadores[t.id] ? <span className="ml-1.5 num text-[11px] rounded bg-warnsoft text-warn px-1.5">{contadores[t.id]}</span> : null}
          </button>
        ))}
      </div>

      <Contenido p={p} ej={ej} />
    </div>
  );
}
