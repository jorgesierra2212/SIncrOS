import React, { useEffect, useRef, useState } from 'react';
import { ArrowUp, Paperclip, ChevronRight, ChevronDown, Loader2, Share2, Plus, X, FileSpreadsheet } from 'lucide-react';
import { useProcess } from './ProcessStore';
import { useApp } from '../context';
import { PROFILES } from '../../data/mock';
import type { ArchivoItem } from '../../data/types';
import type { ChatMsg } from '../../data/agentScript';

function Pasos({ steps }: { steps: string[] }) {
  const [open, setOpen] = useState(false);
  if (!steps?.length) return null;
  return (
    <div className="mt-1">
      <button onClick={() => setOpen(o => !o)} className="inline-flex items-center gap-1 text-xs text-mut hover:text-txt">
        {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />} Trayectoria · {steps.length} pasos
      </button>
      {open && <ol className="mt-1 ml-5 list-decimal text-xs text-mut space-y-0.5">{steps.map((s, i) => <li key={i}>{s}</li>)}</ol>}
    </div>
  );
}

function Mensaje({ m }: { m: ChatMsg }) {
  if (m.role === 'user') {
    return (
      <div className="flex flex-col items-end gap-1">
        <div className="bg-brandsoft rounded-xl px-4 py-2.5 max-w-[80%] text-[15px]">{m.text}</div>
        {m.files?.length ? <div className="flex gap-1">{m.files.map(f => <span key={f.id} className="text-xs bg-paper border border-line rounded px-2 py-0.5">{f.nombre}</span>)}</div> : null}
      </div>
    );
  }
  return (
    <div>
      <div className="text-xs text-mut">Respondió <b className="text-txt font-medium">{m.reply?.agent ?? 'Agente'}</b></div>
      {m.reply && <Pasos steps={m.reply.steps} />}
      <p className="text-[15px] leading-relaxed mt-1.5 max-w-[75ch] whitespace-pre-line">{m.text}</p>
    </div>
  );
}

export default function ChatPanel({ convId, preguntas = [], alto = 'h-[520px]' }: { convId: string | null; preguntas?: string[]; alto?: string }) {
  const { conversaciones, enviarMensaje, escribiendo, compartir } = useProcess();
  const { profile } = useApp();
  const conv = conversaciones.find(c => c.id === convId) ?? null;
  const [texto, setTexto] = useState('');
  const [adjuntos, setAdjuntos] = useState<ArchivoItem[]>([]);
  const [compartirAbierto, setCompartirAbierto] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const finRef = useRef<HTMLDivElement>(null);

  useEffect(() => { finRef.current?.scrollIntoView({ block: 'end' }); }, [conv?.mensajes.length, escribiendo]);

  if (!conv) return <div className="text-sm text-mut p-6">Seleccione o cree una conversación.</div>;
  const esDueno = conv.dueno === profile.id;
  const duenoNombre = PROFILES.find(p => p.id === conv.dueno)?.person;

  const enviar = (t = texto) => {
    if (!t.trim() || escribiendo) return;
    enviarMensaje(conv.id, t, adjuntos);
    setTexto('');
    setAdjuntos([]);
  };

  const adjuntar = (files: FileList) => {
    const nuevos: ArchivoItem[] = Array.from(files).map((f, i) => ({
      id: `ADJ-${Date.now()}-${i}`, nombre: f.name,
      tipo: /\.pdf$/i.test(f.name) ? 'pdf' : /\.pptx?$/i.test(f.name) ? 'powerpoint' : 'excel',
      tamano: `${Math.max(1, Math.round(f.size / 1024))} KB`, fecha: 'Ahora', origen: 'Cargado por usuario',
    }));
    setAdjuntos(a => [...a, ...nuevos]);
  };

  return (
    <div className={`flex flex-col bg-white border border-line rounded-lg ${alto}`}>
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-line">
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium truncate">{conv.titulo}</div>
          <div className="text-xs text-mut">
            {esDueno ? 'Su conversación' : `De ${duenoNombre}, compartida con usted`} · actualizada {conv.actualizada}
            {conv.compartidaCon.length > 0 && esDueno && ` · compartida con ${conv.compartidaCon.length}`}
          </div>
        </div>
        {esDueno && (
          <div className="relative">
            <button onClick={() => setCompartirAbierto(o => !o)} className="inline-flex items-center gap-1 text-xs border border-line rounded px-2 py-1 hover:bg-paper"><Share2 size={12} /> Compartir</button>
            {compartirAbierto && (
              <div className="absolute right-0 top-full mt-1 z-20 bg-white border border-line rounded-lg shadow-lg w-64 p-2">
                <div className="text-xs text-mut px-1 pb-1">Compartir con</div>
                {PROFILES.filter(p => p.id !== profile.id).map(p => (
                  <label key={p.id} className="flex items-center gap-2 text-sm px-1 py-1 hover:bg-paper rounded">
                    <input type="checkbox" checked={conv.compartidaCon.includes(p.id)}
                      onChange={e => compartir(conv.id, e.target.checked ? [...conv.compartidaCon, p.id] : conv.compartidaCon.filter(x => x !== p.id))} />
                    {p.person} <span className="text-xs text-mut truncate">· {p.role}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5">
        {conv.mensajes.length === 0 && (
          <div className="text-sm text-mut">
            <p>Pregunte en lenguaje natural. El agente usa como contexto el proceso y la ejecución seleccionada.</p>
            {preguntas.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {preguntas.map(p => <button key={p} onClick={() => enviar(p)} className="text-[13px] bg-white border border-line rounded-full px-3 py-1 hover:border-brand hover:text-brand text-left">{p}</button>)}
              </div>
            )}
          </div>
        )}
        {conv.mensajes.map((m, i) => <Mensaje key={i} m={m} />)}
        {escribiendo === conv.id && <div className="flex items-center gap-2 text-sm text-mut"><Loader2 size={15} className="animate-spin" /> El agente está trabajando…</div>}
        <div ref={finRef} />
      </div>

      <div className="border-t border-line p-3">
        {adjuntos.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-2">
            {adjuntos.map(a => (
              <span key={a.id} className="inline-flex items-center gap-1 text-xs bg-paper border border-line rounded px-2 py-0.5">
                <FileSpreadsheet size={12} />{a.nombre}
                <button onClick={() => setAdjuntos(x => x.filter(y => y.id !== a.id))} aria-label="Quitar adjunto"><X size={11} /></button>
              </span>
            ))}
          </div>
        )}
        <div className="flex items-end gap-2">
          <button onClick={() => fileRef.current?.click()} className="p-2 text-mut hover:text-txt" aria-label="Adjuntar Excel, PDF o PowerPoint"><Paperclip size={16} /></button>
          <input ref={fileRef} type="file" multiple accept=".xlsx,.xls,.csv,.pdf,.ppt,.pptx" hidden onChange={e => e.target.files && adjuntar(e.target.files)} />
          <textarea value={texto} onChange={e => setTexto(e.target.value)} rows={1}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); enviar(); } }}
            placeholder="Pregunte al agente de este proceso…" aria-label="Mensaje"
            className="flex-1 resize-none border border-line rounded-lg px-3 py-2 text-[15px] outline-none focus:border-brand" />
          <button onClick={() => enviar()} disabled={!texto.trim() || !!escribiendo} aria-label="Enviar"
            className="w-9 h-9 rounded-full bg-brand text-white grid place-items-center disabled:opacity-40"><ArrowUp size={16} /></button>
        </div>
      </div>
    </div>
  );
}

export function ListaConversaciones({ procesoId, ejecucionId }: { procesoId?: string; ejecucionId?: string }) {
  const { misConversaciones, convActiva, setConvActiva, nuevaConversacion } = useProcess();
  const lista = misConversaciones.filter(c => (procesoId ? c.procesoId === procesoId && c.ejecucionId === ejecucionId : true));
  return (
    <div className="space-y-1">
      <button onClick={() => nuevaConversacion(procesoId, ejecucionId)} className="w-full inline-flex items-center gap-1.5 text-sm text-brand border border-dashed border-brand/40 rounded-md px-3 py-2 hover:bg-brandsoft">
        <Plus size={14} /> Nueva conversación
      </button>
      {lista.map(c => (
        <button key={c.id} onClick={() => setConvActiva(c.id)}
          className={`w-full text-left rounded-md px-3 py-2 text-sm ${c.id === convActiva ? 'bg-brandsoft text-txt' : 'hover:bg-paper'}`}>
          <div className="truncate font-medium">{c.titulo}</div>
          <div className="text-xs text-mut">{c.actualizada} · {c.mensajes.length} mensajes</div>
        </button>
      ))}
      {lista.length === 0 && <p className="text-xs text-mut px-1">Aún no hay conversaciones en esta ejecución.</p>}
    </div>
  );
}
