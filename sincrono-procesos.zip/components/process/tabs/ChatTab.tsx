import React, { useEffect } from 'react';
import ChatPanel, { ListaConversaciones } from '../ChatPanel';
import { useProcess } from '../ProcessStore';
import type { Ejecucion, ProcesoDef } from '../../../data/process/types';

export default function ChatTab({ p, ej }: { p: ProcesoDef; ej: Ejecucion }) {
  const { misConversaciones, convActiva, setConvActiva } = useProcess();
  const propias = misConversaciones.filter(c => c.procesoId === p.id && c.ejecucionId === ej.id);
  const activa = propias.find(c => c.id === convActiva) ?? propias[0] ?? null;

  useEffect(() => {
    if (activa && activa.id !== convActiva) setConvActiva(activa.id);
  }, [activa?.id]);

  return (
    <div className="grid lg:grid-cols-[260px_1fr] gap-4">
      <div className="bg-white border border-line rounded-lg p-2 h-fit">
        <div className="text-xs text-mut px-1 pb-2">Sus conversaciones en esta ejecución</div>
        <ListaConversaciones procesoId={p.id} ejecucionId={ej.id} />
      </div>
      {activa ? (
        <ChatPanel convId={activa.id} preguntas={p.workflow.quickQuestions ?? []} />
      ) : (
        <div className="bg-white border border-line rounded-lg p-6 text-sm text-mut">Cree una conversación para preguntarle al agente sobre esta ejecución.</div>
      )}
    </div>
  );
}
