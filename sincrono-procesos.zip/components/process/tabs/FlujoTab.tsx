import React, { useMemo } from 'react';
import ProcessFlowDAG from '../../workflow/ProcessFlowDAG';
import { useProcess } from '../ProcessStore';
import { useApp } from '../../context';
import type { Ejecucion, ProcesoDef } from '../../../data/process/types';
import type { ProcessWorkflow, NodeStatus } from '../../../data/workflowModels';

/** Ajusta el estado de los pasos según la ejecución seleccionada. */
export function workflowPara(p: ProcesoDef, ej: Ejecucion): ProcessWorkflow {
  const wf = p.workflow;
  if (ej.estado === 'Esperando aprobación') return wf;
  const n = wf.nodes.length;
  const estado = (i: number): NodeStatus => {
    if (ej.estado === 'Completada') return 'completed';
    if (ej.estado === 'Con error') return i < n - 1 ? 'completed' : 'failed';
    const actual = wf.nodes.findIndex(x => x.data.label === ej.pasoActual);
    return i < actual ? 'completed' : i === actual ? 'running' : 'pending';
  };
  return {
    ...wf,
    id: `${wf.id}-${ej.id}`,
    status: ej.estado === 'Completada' ? 'completed' : ej.estado === 'Con error' ? 'action_required' : 'running',
    nodes: wf.nodes.map((x, i) => ({ ...x, data: { ...x.data, status: estado(i) } })),
  };
}

export default function FlujoTab({ p, ej }: { p: ProcesoDef; ej: Ejecucion }) {
  const { puede, registrarAprobacionPaso } = useProcess();
  const { profile } = useApp();
  const wf = useMemo(() => workflowPara(p, ej), [p, ej]);
  const perm = puede(p.id);
  return (
    <ProcessFlowDAG
      key={wf.id}
      workflow={wf}
      embedded
      canExecute={perm.ejecutar}
      canApprove={perm.aprobar && ej.estado === 'Esperando aprobación'}
      actor={profile.person}
      onApproved={(_, label) => registrarAprobacionPaso(p.id, label)}
    />
  );
}
