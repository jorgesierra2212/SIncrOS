import React, { useState } from 'react';
import { Send, RotateCcw, Check, FileText, ShieldCheck } from 'lucide-react';
import { useProcess } from '../ProcessStore';
import { Btn, StatusBadge } from '../../ui';
import { SECUENCIA_ENVIO } from '../../../data/process/types';
import type { Ejecucion, Envio, ProcesoDef } from '../../../data/process/types';

function Linea({ env }: { env: Envio }) {
  const rechazado = env.estado === 'Rechazado';
  const alcanzados = new Set(env.historial.map(h => h.estado));
  const pasos = rechazado ? [...SECUENCIA_ENVIO.slice(0, 4), 'Rechazado' as const] : SECUENCIA_ENVIO;
  return (
    <ol className="flex flex-wrap items-start gap-1">
      {pasos.map((s, i) => {
        const h = [...env.historial].reverse().find(x => x.estado === s);
        const ok = alcanzados.has(s);
        const color = s === 'Rechazado' ? 'bg-bad text-white' : ok ? 'bg-ok text-white' : 'bg-paper text-mut border border-line';
        return (
          <li key={s} className="flex items-start gap-1">
            <div className="flex flex-col items-center w-[104px]">
              <span className={`w-7 h-7 rounded-full grid place-items-center text-xs font-semibold ${color}`}>{ok ? <Check size={14} /> : i + 1}</span>
              <span className="text-[11px] text-center mt-1 leading-tight">{s}</span>
              {h && <span className="text-[10px] text-mut text-center">{h.fecha}<br />{h.quien}</span>}
            </div>
            {i < pasos.length - 1 && <span className={`mt-3.5 h-0.5 w-4 ${alcanzados.has(pasos[i + 1]) ? 'bg-ok' : 'bg-line'}`} />}
          </li>
        );
      })}
    </ol>
  );
}

export default function EnviosTab({ p, ej }: { p: ProcesoDef; ej: Ejecucion }) {
  const { envios, aprobarEnvio, reenviar, puede } = useProcess();
  const [todas, setTodas] = useState(false);
  const [simular, setSimular] = useState(false);
  const perm = puede(p.id);

  if (!p.entidad) {
    return <div className="bg-white border border-line rounded-lg p-6 text-sm text-mut">Este proceso no envía documentos a entidades externas. Su resultado es una decisión interna que queda en Histórico y en la auditoría.</div>;
  }
  const lista = envios.filter(e => e.procesoId === p.id && (todas || e.ejecucionId === ej.id));

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <span className="text-mut">Destino: <b className="text-txt">{p.entidad}</b> · Documento: {p.documentoEnvio}</span>
        <label className="ml-auto inline-flex items-center gap-1.5 text-xs text-mut"><input type="checkbox" checked={todas} onChange={e => setTodas(e.target.checked)} /> Ver envíos de todas las ejecuciones</label>
        <label className="inline-flex items-center gap-1.5 text-xs text-mut" title="Para la demostración: la entidad rechazará el próximo envío que apruebe"><input type="checkbox" checked={simular} onChange={e => setSimular(e.target.checked)} /> Simular rechazo de la entidad</label>
      </div>
      {lista.length === 0 && <div className="bg-white border border-line rounded-lg p-6 text-sm text-mut">No hay envíos para esta ejecución.</div>}
      {lista.map(env => (
        <div key={env.id} className="bg-white border border-line rounded-lg p-4">
          <div className="flex flex-wrap items-start gap-2 mb-3">
            <div className="flex-1 min-w-0">
              <div className="text-xs text-mut">{env.id} · {env.entidad}{env.reintentos ? ` · reintentos: ${env.reintentos}` : ''}</div>
              <div className="font-medium flex items-center gap-1.5"><FileText size={14} /> {env.documento}</div>
            </div>
            <StatusBadge s={env.estado} />
          </div>
          <div className="overflow-x-auto pb-1"><Linea env={env} /></div>
          <div className="grid sm:grid-cols-2 gap-2 mt-3 text-sm">
            <div className="bg-paper rounded px-3 py-2"><span className="text-mut text-xs block">Radicado o CUFE</span>{env.radicado ?? '—'}</div>
            <div className="bg-paper rounded px-3 py-2"><span className="text-mut text-xs block">Evidencia del acuse</span>{env.evidencia ?? 'Pendiente'}</div>
          </div>
          {env.motivoRechazo && <div className="mt-2 text-sm bg-badsoft text-bad rounded px-3 py-2">Motivo del rechazo: {env.motivoRechazo}</div>}
          <div className="flex flex-wrap gap-2 mt-3">
            {env.estado === 'Preparado' && ej.estado === 'Esperando aprobación' && env.ejecucionId === ej.id && (
              <span className="text-xs text-warn">Primero se aprueba el paso humano en Flujo; después se habilita el envío.</span>
            )}
            {env.estado === 'Preparado' && !(ej.estado === 'Esperando aprobación' && env.ejecucionId === ej.id) && (perm.aprobar
              ? <Btn kind="primary" onClick={() => aprobarEnvio(env.id, simular)}><ShieldCheck size={14} /> Aprobar y enviar</Btn>
              : <span className="text-xs text-warn">Nada se envía sin aprobación: requiere el rol Aprobador.</span>)}
            {env.estado === 'Rechazado' && perm.aprobar && <Btn onClick={() => reenviar(env.id)}><RotateCcw size={14} /> Corregir y reenviar</Btn>}
            {['Enviado', 'Acuse recibido'].includes(env.estado) && <span className="text-xs text-mut inline-flex items-center gap-1"><Send size={12} /> Esperando respuesta de {env.entidad}…</span>}
          </div>
        </div>
      ))}
    </div>
  );
}
