import React, { useState, useMemo } from 'react';
import {
  Search, Filter, ArrowUpDown, ArrowUp, ArrowDown, Download, AlertTriangle,
  CheckCircle2, HelpCircle, Eye, Edit3, Save, X, Sparkles, ChevronRight, Calculator
} from 'lucide-react';
import { cop } from '../data/mock';
import { exportTableToExcel } from '../utils/export';

export interface GridRow {
  id: string;
  concepto: string;
  categoria: string;
  calc: number;
  xm: number;
  diff: number;
  regla: string;
  umbral: number;
  estado: 'Cuadra' | 'Reclamar' | 'Revisar' | 'Ajustado Manual';
  detalles?: {
    formula: string;
    variables?: { nombre: string; valor: string }[];
    origenXM?: string;
    explicacion?: string;
  };
}

interface AirtableGridProps {
  rows: GridRow[];
  processTitle: string;
  versionLabel?: string;
  onAskAgent?: (query: string) => void;
  onManualEdit?: (id: string, newVal: number, justification: string) => void;
}

export default function AirtableGrid({
  rows: initialRows,
  processTitle,
  versionLabel = 'TX2',
  onAskAgent,
  onManualEdit,
}: AirtableGridProps) {
  const [rows, setRows] = useState<GridRow[]>(initialRows);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('todas');
  const [onlyAlerts, setOnlyAlerts] = useState(false);
  const [sortField, setSortField] = useState<'concepto' | 'calc' | 'xm' | 'diff'>('diff');
  const [sortAsc, setSortAsc] = useState(false);

  // Drawer detail for selected row
  const [selectedRow, setSelectedRow] = useState<GridRow | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [editJustification, setEditJustification] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);

  // Categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    rows.forEach(r => set.add(r.categoria));
    return ['todas', ...Array.from(set)];
  }, [rows]);

  // Filtering & Sorting
  const filteredRows = useMemo(() => {
    return rows
      .filter(r => {
        if (onlyAlerts && Math.abs(r.diff) < r.umbral) return false;
        if (categoryFilter !== 'todas' && r.categoria !== categoryFilter) return false;
        if (search.trim()) {
          const q = search.toLowerCase();
          return (
            r.concepto.toLowerCase().includes(q) ||
            r.categoria.toLowerCase().includes(q) ||
            r.regla.toLowerCase().includes(q) ||
            r.id.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];
        if (sortField === 'diff') {
          valA = Math.abs(a.diff);
          valB = Math.abs(b.diff);
        }
        if (typeof valA === 'string') {
          return sortAsc ? (valA as string).localeCompare(valB as string) : (valB as string).localeCompare(valA as string);
        }
        return sortAsc ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
      });
  }, [rows, search, categoryFilter, onlyAlerts, sortField, sortAsc]);

  const toggleSort = (field: 'concepto' | 'calc' | 'xm' | 'diff') => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const handleExportExcel = () => {
    exportTableToExcel(
      filteredRows.map(r => ({
        ID: r.id,
        Concepto: r.concepto,
        Categoria: r.categoria,
        Calculado_Enersinc: r.calc,
        Oficial_XM: r.xm,
        Diferencia_Neta: r.diff,
        Diferencia_Absoluta: Math.abs(r.diff),
        Regla_CREG: r.regla,
        Estado: r.estado,
      })),
      `${processTitle.toLowerCase().replace(/\s+/g, '_')}_${versionLabel}.xlsx`
    );
  };

  const handleOpenRow = (r: GridRow) => {
    setSelectedRow(r);
    setEditValue(r.calc.toString());
    setEditJustification('');
    setIsEditing(false);
  };

  const handleSaveEdit = () => {
    if (!selectedRow) return;
    const num = parseFloat(editValue);
    if (isNaN(num)) return;
    if (!editJustification.trim()) {
      alert('Debe ingresar una justificación regulatoria para registrar el respaldo manual.');
      return;
    }

    setRows(prev =>
      prev.map(r =>
        r.id === selectedRow.id
          ? {
              ...r,
              calc: num,
              diff: num - r.xm,
              estado: 'Ajustado Manual',
            }
          : r
      )
    );

    if (onManualEdit) {
      onManualEdit(selectedRow.id, num, editJustification.trim());
    }

    setSelectedRow(prev => (prev ? { ...prev, calc: num, diff: num - prev.xm, estado: 'Ajustado Manual' } : null));
    setIsEditing(false);
  };

  return (
    <div className="border border-line rounded-xl bg-white shadow-xs overflow-hidden flex flex-col">
      {/* Airtable-like Toolbar */}
      <div className="p-3 bg-paper/60 border-b border-line flex flex-wrap items-center justify-between gap-2.5 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          {/* Quick Search */}
          <div className="relative w-48 sm:w-64">
            <Search size={13} className="absolute left-2.5 top-2.5 text-mut" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar concepto o regla..."
              className="w-full bg-white border border-line rounded-md pl-8 pr-2.5 py-1.5 text-xs outline-none focus:border-brand"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1 bg-white border border-line rounded-md px-2 py-1">
            <Filter size={12} className="text-mut" />
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="bg-transparent text-xs text-txt outline-none cursor-pointer capitalize"
            >
              {categories.map(c => (
                <option key={c} value={c}>
                  {c === 'todas' ? 'Todas las categorías' : c}
                </option>
              ))}
            </select>
          </div>

          {/* Only Alerts Toggle */}
          <button
            onClick={() => setOnlyAlerts(!onlyAlerts)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md font-medium border transition-colors ${
              onlyAlerts
                ? 'bg-badsoft border-bad/30 text-bad font-semibold'
                : 'bg-white border-line text-mut hover:text-txt'
            }`}
          >
            <AlertTriangle size={13} />
            <span>Solo discrepancias ({rows.filter(r => Math.abs(r.diff) >= r.umbral).length})</span>
          </button>
        </div>

        {/* Action Right */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-mut hidden md:inline font-mono">
            {filteredRows.length} de {rows.length} registros
          </span>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-line bg-white hover:bg-paper text-txt font-medium transition-colors"
            title="Descargar matriz en Excel"
          >
            <Download size={13} />
            <span>Excel (.xlsx)</span>
          </button>
        </div>
      </div>

      {/* Grid Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left border-collapse">
          <thead>
            <tr className="bg-paper/40 border-b border-line text-[11px] font-semibold text-mut uppercase tracking-wider">
              <th className="py-2.5 px-3 w-10 text-center">#</th>
              <th
                onClick={() => toggleSort('concepto')}
                className="py-2.5 px-3 cursor-pointer hover:bg-line/40 transition-colors select-none"
              >
                <div className="flex items-center gap-1">
                  <span>Concepto Comercial</span>
                  {sortField === 'concepto' && (sortAsc ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                </div>
              </th>
              <th className="py-2.5 px-3">Categoría</th>
              <th
                onClick={() => toggleSort('calc')}
                className="py-2.5 px-3 text-right cursor-pointer hover:bg-line/40 transition-colors select-none"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Calculado (Enersinc)</span>
                  {sortField === 'calc' && (sortAsc ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                </div>
              </th>
              <th
                onClick={() => toggleSort('xm')}
                className="py-2.5 px-3 text-right cursor-pointer hover:bg-line/40 transition-colors select-none"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Oficial XM</span>
                  {sortField === 'xm' && (sortAsc ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                </div>
              </th>
              <th
                onClick={() => toggleSort('diff')}
                className="py-2.5 px-3 text-right cursor-pointer hover:bg-line/40 transition-colors select-none"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Diferencia Neta</span>
                  {sortField === 'diff' && (sortAsc ? <ArrowUp size={12} /> : <ArrowDown size={12} />)}
                </div>
              </th>
              <th className="py-2.5 px-3">Regla CREG</th>
              <th className="py-2.5 px-3 text-center">Estado</th>
              <th className="py-2.5 px-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line font-mono text-[12px]">
            {filteredRows.map((r, idx) => {
              const hasAlert = Math.abs(r.diff) >= r.umbral;
              const isSelected = selectedRow?.id === r.id;
              return (
                <tr
                  key={r.id}
                  onClick={() => handleOpenRow(r)}
                  className={`hover:bg-brandsoft/20 cursor-pointer transition-colors ${
                    isSelected ? 'bg-brandsoft/30 ring-1 ring-inset ring-brand' : hasAlert ? 'bg-badsoft/20' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 text-center text-mut font-sans text-[11px]">{idx + 1}</td>
                  <td className="py-2.5 px-3 font-sans font-semibold text-txt">
                    <div className="flex items-center gap-1.5">
                      {hasAlert && (
                        <span
                          className="w-4 h-4 rounded-full bg-bad text-white text-[10px] font-bold grid place-items-center shrink-0"
                          title="Supera umbral de reclamación"
                        >
                          !
                        </span>
                      )}
                      <span className="truncate max-w-[240px]">{r.concepto}</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-sans text-mut text-[11.5px]">{r.categoria}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-txt">{cop(r.calc)}</td>
                  <td className="py-2.5 px-3 text-right text-mut">{cop(r.xm)}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span
                      className={`font-semibold ${
                        hasAlert ? 'text-bad font-bold' : r.diff === 0 ? 'text-ok font-normal' : 'text-warn'
                      }`}
                    >
                      {r.diff === 0 ? '$0' : cop(r.diff)}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-mut text-[11px]">
                    <span className="bg-paper px-1.5 py-0.5 rounded border border-line/60">{r.regla}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-sans">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        r.estado === 'Reclamar'
                          ? 'bg-badsoft text-bad border border-bad/30'
                          : r.estado === 'Ajustado Manual'
                          ? 'bg-oksoft text-ok border border-ok/30'
                          : r.estado === 'Revisar'
                          ? 'bg-warnsoft text-warn border border-warn/30'
                          : 'bg-paper text-mut'
                      }`}
                    >
                      {r.estado}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-sans">
                    <div className="flex items-center justify-center gap-1.5" onClick={e => e.stopPropagation()}>
                      <button
                        onClick={() => handleOpenRow(r)}
                        className="p-1 rounded text-mut hover:text-brand hover:bg-paper"
                        title="Ver detalle de la fila"
                      >
                        <Eye size={13} />
                      </button>
                      {onAskAgent && (
                        <button
                          onClick={() =>
                            onAskAgent(`Explica la diferencia en ${r.concepto}: Calculado ${cop(r.calc)} vs XM ${cop(r.xm)}`)
                          }
                          className="p-1 rounded text-mut hover:text-brand hover:bg-paper"
                          title="Preguntar al agente sobre esta fila"
                        >
                          <Sparkles size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredRows.length === 0 && (
              <tr>
                <td colSpan={9} className="py-8 text-center text-mut font-sans text-xs">
                  No se encontraron registros con los filtros seleccionados.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Row Detail Drawer (Slide-Over / Inspector) */}
      {selectedRow && (
        <div className="p-4 bg-paper/50 border-t border-line text-xs">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-line">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold bg-brand text-white px-2 py-0.5 rounded">
                {selectedRow.id}
              </span>
              <h4 className="font-bold text-sm text-txt">{selectedRow.concepto}</h4>
              <span className="text-[11px] text-mut">({selectedRow.categoria})</span>
            </div>
            <button onClick={() => setSelectedRow(null)} className="text-mut hover:text-txt p-1">
              <X size={16} />
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            {/* Column 1: Financial Delta */}
            <div className="bg-white p-3 rounded-lg border border-line space-y-2">
              <span className="text-[10.5px] font-semibold uppercase tracking-wider text-mut block">
                Cotejo Financiero
              </span>
              <div className="flex justify-between">
                <span className="text-mut">Calculado Enersinc:</span>
                <span className="font-mono font-semibold text-txt">{cop(selectedRow.calc)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-mut">Publicado XM:</span>
                <span className="font-mono text-txt">{cop(selectedRow.xm)}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-line">
                <span className="text-mut font-semibold">Diferencia:</span>
                <span className={`font-mono font-bold ${Math.abs(selectedRow.diff) >= selectedRow.umbral ? 'text-bad' : 'text-ok'}`}>
                  {cop(selectedRow.diff)}
                </span>
              </div>
              <div className="text-[10.5px] text-mut pt-1">
                Umbral de tolerancia: <b className="text-txt">{cop(selectedRow.umbral)}</b>
              </div>
            </div>

            {/* Column 2: Formula & CREG */}
            <div className="bg-white p-3 rounded-lg border border-line space-y-2">
              <span className="text-[10.5px] font-semibold uppercase tracking-wider text-mut block">
                Regulación Aplicada
              </span>
              <div className="font-semibold text-brand">{selectedRow.regla}</div>
              {selectedRow.detalles?.formula && (
                <div className="p-2 bg-ink text-white rounded font-mono text-[10.5px] break-words">
                  {selectedRow.detalles.formula}
                </div>
              )}
              {selectedRow.detalles?.explicacion && (
                <p className="text-[11px] text-mut leading-tight">
                  {selectedRow.detalles.explicacion}
                </p>
              )}
            </div>

            {/* Column 3: Actions & Manual Override */}
            <div className="bg-white p-3 rounded-lg border border-line space-y-2 flex flex-col justify-between">
              <div>
                <span className="text-[10.5px] font-semibold uppercase tracking-wider text-mut block mb-1">
                  Acciones & Respaldo
                </span>
                {!isEditing ? (
                  <div className="space-y-1.5">
                    {onAskAgent && (
                      <button
                        onClick={() =>
                          onAskAgent(`Audita a profundidad la discrepancia de ${cop(selectedRow.diff)} en ${selectedRow.concepto}`)
                        }
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-brandsoft hover:bg-brandsoft/80 text-brand font-medium rounded text-xs transition-colors"
                      >
                        <Sparkles size={13} /> Consultar al agente sobre este concepto
                      </button>
                    )}
                    <button
                      onClick={() => setIsEditing(true)}
                      className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 bg-paper hover:bg-line/40 text-txt font-medium rounded text-xs transition-colors"
                    >
                      <Edit3 size={13} /> Respaldo manual (Editar valor a mano)
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div>
                      <label className="text-[10.5px] text-mut block mb-0.5">Nuevo valor corregido ($ COP):</label>
                      <input
                        type="text"
                        value={editValue}
                        onChange={e => setEditValue(e.target.value)}
                        className="w-full p-1.5 border border-line rounded text-xs font-mono outline-none focus:border-brand"
                      />
                    </div>
                    <div>
                      <label className="text-[10.5px] text-mut block mb-0.5">Justificación obligatoria:</label>
                      <input
                        type="text"
                        value={editJustification}
                        onChange={e => setEditJustification(e.target.value)}
                        placeholder="Motivo del ajuste..."
                        className="w-full p-1.5 border border-line rounded text-xs outline-none focus:border-brand"
                      />
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setIsEditing(false)}
                        className="flex-1 py-1 bg-paper text-mut hover:text-txt rounded text-[11px]"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleSaveEdit}
                        className="flex-1 py-1 bg-ok text-white font-semibold rounded text-[11px] flex items-center justify-center gap-1"
                      >
                        <Save size={12} /> Guardar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
