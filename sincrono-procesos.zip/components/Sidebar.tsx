import React, { useState } from 'react';
import {
  Inbox, MessageSquare, Bot, CalendarClock, Workflow, LayoutGrid, FileStack, Plus, ChevronDown, ChevronRight, X, Gauge,
  Radio, Activity, FileUp, ScanSearch, Receipt, Users, Scale, Sigma, BookOpen, LineChart, Gavel, ShieldAlert, Landmark, Factory, Droplets, Settings,
  Zap, TrendingUp, Clock, FileCheck, FileMinus, SendHorizontal, FolderOpen, Puzzle, Cpu, LifeBuoy, FileText, Search, MessagesSquare,
} from 'lucide-react';
import { useApp } from './context';
import { useProcess } from './process/ProcessStore';
import { PROFILES, Profile, VIEWS, ViewId } from '../data/mock';
import { DOMINIOS } from '../data/process/types';

export const ICONS: Record<ViewId, React.ElementType> = {
  inicio: Gauge, bandeja: Inbox, conversacion: MessageSquare, agentes: Bot, tareas: CalendarClock, procesos: Workflow, artefactos: FileStack,
  despacho_ofertas: Zap, despacho_prog_real: TrendingUp, despacho_redespacho: Clock, despacho_intradiario: LineChart,
  liquidacion: Scale, motor: Sigma, garantias: Landmark, reclamaciones: FileText,
  facturacion: Receipt, facturas_dian: FileCheck, notas_credito: FileMinus, envio_erp: SendHorizontal, usuarios: Users,
  fronteras: Radio, critica: ScanSearch, srm: FileUp, aenc: Activity, informe_anual: FileStack,
  contratos: BookOpen, posicion: LineChart, sicep: Gavel, riesgo: ShieldAlert, escenarios: Droplets,
  supervision: Factory, mercado: Droplets,
  plugins: Puzzle, integraciones: Cpu, archivos: FolderOpen, soporte: LifeBuoy, admin: Settings,
  proceso: Workflow, mis_conversaciones: MessagesSquare, equipos: Users,
};

/** Consulta sin flujo: no son procesos. */
const TABLEROS: ViewId[] = ['mercado', 'posicion', 'riesgo', 'escenarios', 'contratos', 'sicep', 'fronteras', 'supervision', 'despacho_prog_real', 'despacho_redespacho', 'despacho_intradiario', 'aenc', 'usuarios', 'informe_anual'];
const PLATAFORMA: ViewId[] = ['agentes', 'tareas', 'motor', 'plugins', 'integraciones', 'archivos', 'artefactos', 'soporte', 'admin'];

const DOT: Record<string, string> = {
  'Esperando aprobación': 'bg-[#E0A040]', 'En curso': 'bg-[#6F93E8]', Completada: 'bg-[#3BB58F]', 'Con error': 'bg-[#E0675B]',
};

function Item({ v, count, label }: { v: ViewId; count?: number; label?: string }) {
  const { view, go } = useApp();
  const Icon = ICONS[v] || LayoutGrid;
  const active = view === v;
  return (
    <button onClick={() => go(v)} aria-current={active ? 'page' : undefined}
      className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-[13.5px] text-left ${active ? 'bg-white/10 text-white' : 'text-[#B9C4D4] hover:bg-white/5 hover:text-white'}`}>
      <Icon size={15} className="shrink-0" />
      <span className="flex-1 truncate">{label ?? VIEWS[v].label}</span>
      {count ? <span className="num text-[11px] rounded bg-warn text-white px-1.5">{count}</span> : null}
    </button>
  );
}

function Section({ title, children, action, plegable = false, inicial = true }: { title: string; children: React.ReactNode; action?: React.ReactNode; plegable?: boolean; inicial?: boolean }) {
  const [abierta, setAbierta] = useState(inicial);
  return (
    <div className="mt-4">
      <div className="flex items-center justify-between px-2.5 mb-1">
        {plegable ? (
          <button onClick={() => setAbierta(a => !a)} className="inline-flex items-center gap-1 text-[11px] font-semibold tracking-wider uppercase text-[#7F8DA3] hover:text-white" aria-expanded={abierta}>
            {abierta ? <ChevronDown size={12} /> : <ChevronRight size={12} />}{title}
          </button>
        ) : <span className="text-[11px] font-semibold tracking-wider uppercase text-[#7F8DA3]">{title}</span>}
        {action}
      </div>
      {abierta && <div className="space-y-0.5">{children}</div>}
    </div>
  );
}

export default function Sidebar({ open, onClose, onSwitch }: { open: boolean; onClose: () => void; onSwitch: (p: Profile) => void }) {
  const { profile, go, view, brand } = useApp();
  const { visibles, bandeja, abrir, activo, ejecucionActiva, misConversaciones, setConvActiva, nuevaConversacion, rol } = useProcess();
  const [menu, setMenu] = useState(false);
  const [filtro, setFiltro] = useState('');
  const f = filtro.toLowerCase();
  const coincide = (t: string) => !f || t.toLowerCase().includes(f);

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={onClose} />}
      <aside style={{ backgroundColor: brand.colorSecundario || '#0F1E33' }}
        className={`fixed lg:static z-40 inset-y-0 left-0 w-[268px] shrink-0 text-white flex flex-col transition-transform ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="flex items-center justify-between px-3.5 pt-3.5 pb-2.5 border-b border-white/10">
          <div className="flex items-center gap-2.5 min-w-0">
            <div style={{ backgroundColor: brand.colorPrimario || '#2459D6' }} className="w-7 h-7 rounded-md grid place-items-center font-bold text-sm shrink-0">{brand.logoIcon || 'E'}</div>
            <div className="leading-tight min-w-0">
              <div className="font-semibold text-[13.5px] truncate">{brand.nombreProducto || 'Enersinc OS'}</div>
              <div className="text-[10px] text-[#8C9BB0] truncate">Mercado Mayorista (MEM · XM)</div>
            </div>
          </div>
          <button className="lg:hidden text-[#B9C4D4] p-1" onClick={onClose} aria-label="Cerrar menú"><X size={18} /></button>
        </div>

        <div className="p-2.5 pb-0 space-y-2">
          <label className="flex items-center gap-2 bg-white/5 rounded-md px-2.5 py-1.5 text-[13px] text-[#B9C4D4]">
            <Search size={14} />
            <input value={filtro} onChange={e => setFiltro(e.target.value)} placeholder="Filtrar procesos y tableros" className="bg-transparent outline-none flex-1 text-white placeholder:text-[#7F8DA3]" />
          </label>
          <button onClick={() => { nuevaConversacion(); go('mis_conversaciones'); }}
            className="w-full flex items-center justify-center gap-2 rounded-md border border-white/15 py-1.5 text-sm hover:bg-white/5">
            <Plus size={15} /> Nueva conversación
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-2.5 pb-4">
          <Section title="Trabajo">
            <Item v="bandeja" count={bandeja.length} />
            <Item v="mis_conversaciones" count={undefined} />
          </Section>

          <Section title="Procesos" action={<button className="text-[11px] text-[#9DB4EE] hover:underline" onClick={() => go('procesos')}>Ver todos</button>}>
            {DOMINIOS.map(d => {
              const ps = visibles.filter(p => p.dominio === d && coincide(p.nombre));
              if (!ps.length) return null;
              return (
                <div key={d} className="mb-1">
                  <div className="px-2.5 pt-1 text-[10.5px] text-[#66758C]">{d}</div>
                  {ps.map(p => {
                    const e = ejecucionActiva(p.id);
                    const act = view === 'proceso' && activo === p.id;
                    return (
                      <button key={p.id} onClick={() => abrir(p.id)} aria-current={act ? 'page' : undefined}
                        className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-[13.5px] text-left ${act ? 'bg-white/10 text-white' : 'text-[#B9C4D4] hover:bg-white/5 hover:text-white'}`}
                        title={`${e.estado} · su rol: ${rol(p.id)}`}>
                        <span className={`w-2 h-2 rounded-full shrink-0 ${DOT[e.estado]}`} />
                        <span className="flex-1 truncate">{p.nombre}</span>
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </Section>

          <Section title="Mis conversaciones" plegable action={<button className="text-[11px] text-[#9DB4EE] hover:underline" onClick={() => go('mis_conversaciones')}>Todas</button>}>
            {misConversaciones.slice(0, 5).map(c => (
              <button key={c.id} onClick={() => { setConvActiva(c.id); c.procesoId ? abrir(c.procesoId, 'chat', c.ejecucionId) : go('mis_conversaciones'); }}
                className="w-full px-2.5 py-1.5 rounded-md text-[13px] text-[#B9C4D4] hover:bg-white/5 hover:text-white text-left">
                <span className="block truncate">{c.titulo}</span>
                <span className="block text-[10.5px] text-[#66758C] truncate">{c.procesoId ? visibles.find(p => p.id === c.procesoId)?.nombre ?? 'Proceso' : 'General'}{c.dueno !== profile.id ? ' · compartida' : ''}</span>
              </button>
            ))}
            {misConversaciones.length === 0 && <p className="px-2.5 text-[12px] text-[#7F8DA3]">Aún no tiene conversaciones.</p>}
          </Section>

          <Section title="Tableros" plegable inicial={false}>
            {TABLEROS.filter(v => coincide(VIEWS[v].label)).map(v => <Item key={v} v={v} />)}
          </Section>

          <Section title="Equipos">
            <Item v="equipos" />
          </Section>

          <Section title="Plataforma" plegable inicial={false}>
            {PLATAFORMA.map(v => <Item key={v} v={v} />)}
          </Section>
        </nav>

        <div className="relative border-t border-white/10 p-2.5">
          <button onClick={() => setMenu(m => !m)} className="w-full flex items-center gap-2 rounded-md p-1.5 hover:bg-white/5 text-left" aria-expanded={menu}>
            <span style={{ backgroundColor: brand.colorPrimario || '#2459D6' }} className="w-7 h-7 rounded-full grid place-items-center text-xs font-semibold shrink-0">{profile.initials}</span>
            <span className="flex-1 min-w-0 leading-tight">
              <span className="block text-xs font-medium truncate">{profile.person}</span>
              <span className="block text-[10.5px] text-[#8C9BB0] truncate">{profile.role}</span>
            </span>
            <ChevronDown size={14} className="text-[#8C9BB0]" />
          </button>
          {menu && (
            <div className="absolute bottom-full left-2 right-2 mb-2 bg-white text-txt rounded-lg shadow-xl border border-line overflow-hidden z-50">
              <div className="px-3 py-2 text-[11px] font-semibold text-mut border-b border-line uppercase tracking-wider">Ver el producto como</div>
              {PROFILES.map(p => (
                <button key={p.id} onClick={() => { onSwitch(p); setMenu(false); }}
                  className={`w-full text-left px-3 py-2 text-xs hover:bg-paper ${p.id === profile.id ? 'font-semibold text-brand' : ''}`}>
                  <div className="font-medium">{p.person}</div><div className="text-[11px] text-mut">{p.role}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
