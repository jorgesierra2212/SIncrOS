import React, { useState, useMemo, useCallback, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  Node,
  Edge,
  useNodesState,
  useEdgesState,
  ConnectionLineType,
} from '@xyflow/react';
import {
  Play, CheckCircle2, AlertTriangle, Terminal, FileCode, Database,
  ArrowRight, ShieldCheck, Undo2, Edit3, Save, X, Sparkles, Filter,
  Maximize2, Minimize2, Layers, RefreshCw, ChevronRight, Activity, Download,
  Bot, HelpCircle, Check, Clock, ChevronDown, Split
} from 'lucide-react';
import CustomFlowNode from './CustomFlowNode';
import { ProcessWorkflow, WorkflowNodeData } from '../../data/workflowModels';
import AirtableGrid, { GridRow } from '../AirtableGrid';
import { useApp } from '../context';

interface ProcessFlowDAGProps {
  workflow: ProcessWorkflow;
  onSelectAirtable?: () => void;
  /** Dentro de ProcessWorkspace: una sola representación (secuencia) y sin encabezado propio. */
  embedded?: boolean;
  canExecute?: boolean;
  canApprove?: boolean;
  actor?: string;
  onApproved?: (stepNumber: number, label: string) => void;
}

const nodeTypes = {
  custom: CustomFlowNode,
};

export default function ProcessFlowDAG({ workflow, onSelectAirtable, embedded = false, canExecute = true, canApprove = true, actor = 'Operador Responsable', onApproved }: ProcessFlowDAGProps) {
  const { decide, addAudit } = useApp();

  // Convert workflow nodes into ReactFlow nodes
  const initialNodes: Node[] = useMemo(() => {
    return workflow.nodes.map(n => ({
      id: n.id,
      type: 'custom',
      position: n.position,
      data: n.data as any,
    }));
  }, [workflow]);

  const initialEdges: Edge[] = useMemo(() => {
    return workflow.edges.map(e => ({
      id: e.id,
      source: e.source,
      target: e.target,
      animated: e.animated ?? true,
      label: e.label,
      style: { stroke: '#94A3B8', strokeWidth: 2 },
      type: ConnectionLineType.SmoothStep,
    }));
  }, [workflow]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  // Selected node for deep inspection drawer
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(workflow.nodes[0]?.id || null);
  const [activeTab, setActiveTab] = useState<'bitacora' | 'entradas' | 'regla' | 'validaciones'>('bitacora');

  // View presentation mode: 'both' | 'stepper' | 'dag'
  const [viewMode, setViewMode] = useState<'both' | 'stepper' | 'dag'>(embedded ? 'stepper' : 'both');

  // Simulation execution state
  const [isExecuting, setIsExecuting] = useState(false);
  const [executionRunCount, setExecutionRunCount] = useState(1);

  // Manual intervention state for selected node
  const [isIntervening, setIsIntervening] = useState(false);
  const [overrideValue, setOverrideValue] = useState('');
  const [overrideReason, setOverrideReason] = useState('');

  // Expand / collapse data grid
  const [showAirtable, setShowAirtable] = useState(false);

  // Agent validation query in the inspector
  const [agentAnswer, setAgentAnswer] = useState<{ query: string; response: string; rule: string } | null>(null);

  // Synchronize when the workflow prop changes
  useEffect(() => {
    setNodes(initialNodes);
    setEdges(initialEdges);
    setSelectedNodeId(workflow.nodes[0]?.id || null);
    setIsIntervening(false);
    setAgentAnswer(null);
  }, [workflow.id, initialNodes, initialEdges, setNodes, setEdges]);

  // Get currently selected node data
  const selectedNode = useMemo(() => {
    const n = nodes.find(item => item.id === selectedNodeId);
    return n ? ((n.data as any) as WorkflowNodeData) : null;
  }, [nodes, selectedNodeId]);

  const onNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    setSelectedNodeId(node.id);
  }, []);

  // Run process by demand (sequential live execution like Airflow task runs)
  const handleExecuteOnDemand = () => {
    setIsExecuting(true);
    setExecutionRunCount(prev => prev + 1);

    // Reset nodes to pending then sequentially update to running and completed
    setNodes(nds =>
      nds.map((n, idx) => ({
        ...n,
        data: {
          ...(n.data as any),
          status: idx === 0 ? 'running' : 'pending',
          duration: undefined,
        },
      }))
    );

    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < workflow.nodes.length) {
        setNodes(nds =>
          nds.map((n, idx) => {
            const data = (n.data as any) as WorkflowNodeData;
            if (idx < currentStep) {
              return {
                ...n,
                data: { ...data, status: 'completed', duration: `${(0.8 + idx * 0.4).toFixed(1)}s` },
              };
            }
            if (idx === currentStep) {
              const isActionRequired = workflow.nodes[idx].data.category === 'aprobacion';
              return {
                ...n,
                data: {
                  ...data,
                  status: isActionRequired ? 'action_required' : 'running',
                  duration: isActionRequired ? undefined : '0.9s',
                },
              };
            }
            return n;
          })
        );
      } else {
        clearInterval(interval);
        setIsExecuting(false);
        addAudit('Agente de Proceso', `Ejecución por demanda del pipeline ${workflow.title}`, 'v3.2', 'nucleo');
      }
    }, 700);
  };

  const handleSaveManualIntervention = () => {
    if (!overrideReason.trim() || !overrideValue.trim() || !selectedNodeId) return;

    setNodes(nds =>
      nds.map(n => {
        if (n.id === selectedNodeId) {
          const d = (n.data as any) as WorkflowNodeData;
          return {
            ...n,
            data: {
              ...d,
              manualOverrideActive: true,
              manualValue: overrideValue,
              manualJustification: overrideReason,
              status: 'completed',
              logs: [
                ...(d.logs || []),
                `[${new Date().toLocaleTimeString('es-CO')}] INTERVENCIÓN MANUAL REGISTRADA: ${overrideValue} | Motivo: ${overrideReason}`,
              ],
            },
          };
        }
        return n;
      })
    );

    addAudit(
      'Operador Humano',
      `Intervención manual en nodo #${selectedNode?.stepNumber}: ${overrideValue} (Motivo: ${overrideReason})`,
      'v3.2',
      'cliente'
    );

    setIsIntervening(false);
    setOverrideValue('');
    setOverrideReason('');
  };

  const handleQuickAgentValidation = (question: string) => {
    let resp = '';
    let rCode = selectedNode?.ruleCode || workflow.reglaPrincipal;

    if (question.includes('discrepancia') || question.includes('causa')) {
      resp = `El análisis detallado para el paso #${selectedNode?.stepNumber} (${selectedNode?.label}) determinó que las series temporales presentaron una desviación respecto a la referencia LAC/XM. El agente detectó que la causa raíz proviene del desfase horario en la recolección telemétrica y la no inclusión de la redeclaración formal IDO en el archivo preliminar. Se generó la propuesta de estimación para salvaguardar el cumplimiento regulatorio antes del corte oficial.`;
    } else if (question.includes('regla') || question.includes('artículo')) {
      resp = `La regla aplicada es ${rCode}. El procedimiento sigue estrictamente la jerarquía oficial: 1) Verificación de sello criptográfico y sincronismo NTP (±5s), 2) Medidor principal calibrado, 3) Medidor de respaldo homologado, 4) Sustitución por promedio histórico en ventana de 4 semanas similares.`;
    } else if (question.includes('impacto')) {
      resp = `Si se rechaza este paso sin intervención manual, el expediente no alcanzará a ser radicado antes del vencimiento oficial (${workflow.officialDeadline}), lo que faculta a XM para aplicar la estimación regulatoria por defecto o iniciar una investigación por incumplimiento del Código de Medida. El impacto económico estimado asciende a $48,4 M COP en reconciliaciones negativas.`;
    } else {
      resp = `Para realizar el respaldo manual en esta pantalla: active el botón "Intervenir y Respaldar a Mano", ingrese el valor corregido respaldado en el acta de calibración o ticket de cuadrilla y proporcione la justificación técnica. El sistema computará el delta y generará la firma inmutable de auditoría.`;
    }

    setAgentAnswer({
      query: question,
      response: resp,
      rule: rCode,
    });
  };

  return (
    <div className="bg-white border border-line rounded-xl shadow-2xs overflow-hidden mb-6">
      {/* Workflow Header & Execution Toolbar */}
      <div className="p-4 md:p-5 border-b border-line bg-gradient-to-r from-paper to-white">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className={embedded ? 'hidden' : ''}>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="text-xs font-bold text-brand bg-brandsoft px-2 py-0.5 rounded font-mono">
                {workflow.shortCode}
              </span>
              <span className="text-xs font-semibold text-mut bg-white px-2 py-0.5 rounded border border-line">
                Horizonte: {workflow.horizonLabel}
              </span>
              <span className="text-xs font-semibold text-mut bg-white px-2 py-0.5 rounded border border-line">
                Regla: {workflow.reglaPrincipal}
              </span>
              {workflow.status === 'action_required' && (
                <span className="text-xs font-bold text-bad bg-badsoft px-2 py-0.5 rounded border border-bad/30 flex items-center gap-1">
                  <AlertTriangle size={12} /> Requiere Aprobación Humana (!)
                </span>
              )}
            </div>

            <h2 className="text-lg md:text-xl font-bold text-txt flex items-center gap-2">
              <span>{workflow.title}</span>
            </h2>
            <p className="text-xs text-mut mt-0.5 flex items-center gap-1.5">
              <span>Agente responsable: <b className="text-txt">{workflow.agentName}</b></span>
              <span>·</span>
              <span className="text-warn font-medium">Plazo oficial: {workflow.officialDeadline}</span>
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Toggle */}
            <div className={embedded ? 'hidden' : 'inline-flex rounded-lg border border-line bg-white p-0.5 shadow-2xs'}>
              <button
                onClick={() => setViewMode('both')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'both' ? 'bg-ink text-white font-bold' : 'text-mut hover:text-txt'
                }`}
                title="Mostrar secuencia lineal y lienzo DAG"
              >
                Completo
              </button>
              <button
                onClick={() => setViewMode('stepper')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'stepper' ? 'bg-ink text-white font-bold' : 'text-mut hover:text-txt'
                }`}
                title="Mostrar solo la secuencia lineal horizontal"
              >
                Secuencia
              </button>
              <button
                onClick={() => setViewMode('dag')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                  viewMode === 'dag' ? 'bg-ink text-white font-bold' : 'text-mut hover:text-txt'
                }`}
                title="Mostrar solo el lienzo de grafo interactivo"
              >
                Grafo DAG
              </button>
            </div>

            {embedded && <span className="text-xs text-mut">Agente responsable: <b className="text-txt">{workflow.agentName}</b> · Plazo: <span className="text-warn">{workflow.officialDeadline}</span></span>}
            {canExecute && <button
              onClick={handleExecuteOnDemand}
              disabled={isExecuting}
              className={`flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-lg text-white transition-all shadow-xs ${
                isExecuting
                  ? 'bg-mut cursor-not-allowed opacity-75'
                  : 'bg-brand hover:bg-[#1D48B2] active:scale-95'
              }`}
            >
              {isExecuting ? (
                <>
                  <RefreshCw size={14} className="animate-spin" />
                  <span>Ejecutando Agentes en Vivo...</span>
                </>
              ) : (
                <>
                  <Play size={14} fill="currentColor" />
                  <span>Ejecutar Proceso por Demanda</span>
                </>
              )}
            </button>}

            <button
              onClick={() => setShowAirtable(!showAirtable)}
              className={`${embedded ? 'hidden' : 'flex'} items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg border transition-colors ${
                showAirtable
                  ? 'bg-ink text-white border-ink'
                  : 'bg-white text-txt border-line hover:bg-paper'
              }`}
            >
              <Layers size={14} />
              <span>{showAirtable ? 'Ocultar Matriz Airtable' : 'Inspeccionar Datos (Airtable)'}</span>
            </button>
          </div>
        </div>

        {/* Workflow Summary KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 mt-4 pt-3.5 border-t border-line/60">
          {workflow.summaryKpis.map((kpi, idx) => (
            <div key={idx} className="bg-white/80 border border-line/70 rounded-lg p-2.5">
              <span className="text-[11px] text-mut block">{kpi.label}</span>
              <span
                className={`text-sm md:text-base font-bold font-mono ${
                  kpi.tone === 'bad'
                    ? 'text-bad'
                    : kpi.tone === 'warn'
                    ? 'text-warn'
                    : 'text-txt'
                }`}
              >
                {kpi.value}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* LINEAR SEQUENCE PIPELINE (AIRFLOW GRID / STEPPER TRACKER) */}
      {(viewMode === 'both' || viewMode === 'stepper') && (
        <div className="p-4 bg-paper/50 border-b border-line">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-txt flex items-center gap-1.5">
              <Split size={14} className="text-brand" />
              <span>Secuencia Lineal del Proceso (Paso a Paso en Orden Cronológico):</span>
            </span>
            <span className="text-[11px] text-mut">
              Haga clic en cualquier paso para ver su bitácora viva, entradas y respaldo manual
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1">
            {workflow.nodes.map((nodeItem, nidx) => {
              const liveNode = nodes.find(n => n.id === nodeItem.id);
              const data = (liveNode?.data as any) as WorkflowNodeData || nodeItem.data;
              const isSelected = selectedNodeId === nodeItem.id;

              return (
                <React.Fragment key={nodeItem.id}>
                  <button
                    onClick={() => setSelectedNodeId(nodeItem.id)}
                    className={`shrink-0 w-[200px] text-left p-2.5 rounded-lg border transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'bg-white border-brand ring-2 ring-brand/30 shadow-xs'
                        : 'bg-white/80 border-line hover:border-mut/60'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between text-[10px] mb-1">
                        <span className="font-mono font-bold text-mut">Paso #{data.stepNumber}</span>
                        {data.status === 'completed' && (
                          <span className="text-ok font-bold flex items-center gap-0.5 bg-oksoft px-1 rounded">
                            <CheckCircle2 size={10} /> OK
                          </span>
                        )}
                        {data.status === 'running' && (
                          <span className="text-brand font-bold flex items-center gap-0.5 bg-brandsoft px-1 rounded">
                            <RefreshCw size={10} className="animate-spin" /> Corriendo
                          </span>
                        )}
                        {data.status === 'action_required' && (
                          <span className="text-bad font-bold flex items-center gap-0.5 bg-badsoft px-1 rounded">
                            <AlertTriangle size={10} /> Firma (!)
                          </span>
                        )}
                        {data.status === 'pending' && (
                          <span className="text-mut font-medium bg-paper px-1 rounded">
                            Pendiente
                          </span>
                        )}
                      </div>

                      <div className={`font-bold text-xs leading-snug line-clamp-1 ${isSelected ? 'text-brand' : 'text-txt'}`}>
                        {data.label}
                      </div>
                      <div className="text-[10.5px] text-mut mt-0.5 truncate">
                        {data.executor}
                      </div>
                    </div>

                    <div className="mt-2 pt-1.5 border-t border-line/60 flex items-center justify-between text-[10px]">
                      <span className="text-mut uppercase font-semibold text-[9px]">{data.category}</span>
                      <span className="font-mono font-medium text-mut">{data.duration || '—'}</span>
                    </div>
                  </button>

                  {nidx < workflow.nodes.length - 1 && (
                    <ArrowRight size={16} className="text-slate-400 shrink-0 mx-0.5" />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      )}

      {/* Main DAG Canvas (Airflow / React Flow interactive diagram) */}
      {(viewMode === 'both' || viewMode === 'dag') && (
        <div className="relative h-[340px] md:h-[380px] bg-[#FAFBFD] border-b border-line">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.25 }}
            minZoom={0.5}
            maxZoom={1.5}
          >
            <Background color="#CBD5E1" gap={16} size={1} />
            <Controls showInteractive={false} className="!bg-white !border !border-line !shadow-xs" />
            <MiniMap
              nodeColor={(node: any) => {
                if (node.data?.status === 'completed') return '#10B981';
                if (node.data?.status === 'running') return '#2459D6';
                if (node.data?.status === 'action_required') return '#EF4444';
                return '#94A3B8';
              }}
              className="!border !border-line !rounded-md"
              style={{ height: 80, width: 120 }}
            />
          </ReactFlow>

          {/* Canvas floating hint */}
          <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xs border border-line/80 px-2.5 py-1 rounded text-[11px] text-mut flex items-center gap-1.5 shadow-2xs pointer-events-none">
            <Sparkles size={12} className="text-brand" />
            <span>Grafo DAG interactivo · Desplace con clic y arrastre para explorar las dependencias.</span>
          </div>
        </div>
      )}

      {/* Deep Inspection Drawer (Task Instance Details inspired by Airflow) */}
      {selectedNode && (
        <div className="p-4 md:p-5 bg-white">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-line">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold text-white bg-ink px-2 py-0.5 rounded">
                  Paso #{selectedNode.stepNumber}
                </span>
                <h3 className="text-base font-bold text-txt">
                  {selectedNode.label}
                </h3>
                {selectedNode.status === 'completed' && (
                  <span className="text-xs text-ok font-semibold bg-oksoft px-2 py-0.5 rounded flex items-center gap-1">
                    <CheckCircle2 size={12} /> Completado ({selectedNode.duration})
                  </span>
                )}
                {selectedNode.status === 'action_required' && (
                  <span className="text-xs text-bad font-semibold bg-badsoft px-2 py-0.5 rounded flex items-center gap-1">
                    <AlertTriangle size={12} /> Acción Requerida (!)
                  </span>
                )}
                {selectedNode.status === 'running' && (
                  <span className="text-xs text-brand font-semibold bg-brandsoft px-2 py-0.5 rounded flex items-center gap-1">
                    <RefreshCw size={12} className="animate-spin" /> En Ejecución
                  </span>
                )}
              </div>
              <p className="text-xs text-mut mt-1">
                Ejecutado por: <b className="text-txt">{selectedNode.executor}</b> · Nivel de Autonomía: <b className="text-txt">{selectedNode.autonomia}</b>
              </p>
            </div>

            {/* Inspector Tabs */}
            <div className="flex items-center gap-1 bg-paper p-1 rounded-lg border border-line flex-wrap">
              <button
                onClick={() => setActiveTab('bitacora')}
                className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeTab === 'bitacora' ? 'bg-white text-brand shadow-2xs' : 'text-mut hover:text-txt'
                }`}
              >
                <Terminal size={13} /> Bitácora en Vivo
              </button>
              <button
                onClick={() => setActiveTab('entradas')}
                className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeTab === 'entradas' ? 'bg-white text-brand shadow-2xs' : 'text-mut hover:text-txt'
                }`}
              >
                <Database size={13} /> Entradas & Hashing
              </button>
              <button
                onClick={() => setActiveTab('regla')}
                className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeTab === 'regla' ? 'bg-white text-brand shadow-2xs' : 'text-mut hover:text-txt'
                }`}
              >
                <FileCode size={13} /> Regla CREG
              </button>
              <button
                onClick={() => setActiveTab('validaciones')}
                className={`text-xs px-2.5 py-1 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeTab === 'validaciones' ? 'bg-white text-brand shadow-2xs' : 'text-mut hover:text-txt'
                }`}
              >
                <Bot size={13} /> Validaciones IA
              </button>
            </div>
          </div>

          {/* Tab 1: Terminal Bitácora */}
          {activeTab === 'bitacora' && (
            <div className="mt-3.5">
              <div className="bg-[#0B132B] text-[#E0E7FF] font-mono text-xs rounded-lg p-3.5 leading-relaxed overflow-x-auto shadow-inner border border-slate-800">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-400">
                  <span>LOG CONSOLE · PROCESO ID: {workflow.id}</span>
                  <span>TASK INSTANCE #{selectedNode.stepNumber}</span>
                </div>
                {selectedNode.logs && selectedNode.logs.length > 0 ? (
                  selectedNode.logs.map((line, lidx) => (
                    <div key={lidx} className="py-0.5">
                      {line.includes('INTERVENCIÓN') ? (
                        <span className="text-amber-300 font-bold">{line}</span>
                      ) : line.includes('Alerta') || line.includes('Diferencia') || line.includes('Requiere') ? (
                        <span className="text-rose-400">{line}</span>
                      ) : (
                        <span className="text-emerald-400/90">{line}</span>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500 italic">No hay logs generados aún para este paso.</div>
                )}
              </div>

              {/* Action buttons inside bitácora */}
              <div className="flex items-center justify-between gap-3 mt-3 flex-wrap">
                <div className="text-xs text-mut">
                  {selectedNode.manualOverrideActive ? (
                    <span className="text-amber-700 font-medium bg-amber-50 px-2 py-1 rounded border border-amber-200">
                      ✓ Nodo intervenido manualmente: {selectedNode.manualValue}
                    </span>
                  ) : (
                    <span>Toda acción deja registro inmutable con firma del operador.</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {selectedNode.canInterveneManually && canExecute && (
                    <button
                      onClick={() => setIsIntervening(!isIntervening)}
                      className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded border border-line hover:bg-paper text-txt transition-colors"
                    >
                      <Edit3 size={12} />
                      <span>{isIntervening ? 'Cancelar Intervención' : 'Intervenir y Respaldar a Mano'}</span>
                    </button>
                  )}

                  {selectedNode.status === 'action_required' && !canApprove && (
                    <span className="text-xs text-warn font-medium">Requiere el rol Aprobador en este proceso</span>
                  )}
                  {selectedNode.status === 'action_required' && canApprove && (
                    <button
                      onClick={() => {
                        setNodes(nds =>
                          nds.map(n =>
                            n.id === selectedNodeId
                              ? {
                                  ...n,
                                  data: {
                                    ...(n.data as any),
                                    status: 'completed',
                                    logs: [
                                      ...((n.data as any).logs || []),
                                      `[${new Date().toLocaleTimeString('es-CO')}] APROBACIÓN HUMANA REGISTRADA POR EL OPERADOR.`,
                                    ],
                                  },
                                }
                              : n
                          )
                        );
                        addAudit(actor, `Aprobación firmada en paso #${selectedNode.stepNumber} de ${workflow.shortCode}`, 'v3.2', 'nucleo');
                        onApproved?.(selectedNode.stepNumber, selectedNode.label);
                      }}
                      className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded bg-ok text-white hover:bg-[#0c6652] transition-colors shadow-xs"
                    >
                      <ShieldCheck size={13} />
                      <span>Aprobar y Firmar Paso</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Manual Intervention Box */}
              {isIntervening && (
                <div className="mt-3 p-3.5 rounded-lg bg-paper border border-line animate-fadeIn">
                  <h4 className="text-xs font-bold text-txt flex items-center gap-1.5 mb-2">
                    <Edit3 size={13} className="text-brand" /> Respaldo Manual · Modificar Valor del Agente
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-semibold text-mut block mb-1">
                        Nuevo Valor / Corrección Manual:
                      </label>
                      <input
                        type="text"
                        value={overrideValue}
                        onChange={e => setOverrideValue(e.target.value)}
                        placeholder="Ej: 4.2 kWh ajustado a 4.19 kWh según calibración física"
                        className="w-full text-xs bg-white border border-line rounded px-2.5 py-1.5 text-txt outline-none focus:border-brand"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-mut block mb-1">
                        Justificación Regulatoria Obligatoria (Auditoría):
                      </label>
                      <input
                        type="text"
                        value={overrideReason}
                        onChange={e => setOverrideReason(e.target.value)}
                        placeholder="Ej: Certificado de calibración de transformador de corriente C-1849"
                        className="w-full text-xs bg-white border border-line rounded px-2.5 py-1.5 text-txt outline-none focus:border-brand"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 mt-2.5">
                    <button
                      onClick={() => setIsIntervening(false)}
                      className="text-xs px-2.5 py-1 rounded text-mut hover:bg-line/40"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleSaveManualIntervention}
                      disabled={!overrideValue.trim() || !overrideReason.trim()}
                      className="text-xs font-bold bg-ink text-white px-3 py-1 rounded hover:bg-ink2 disabled:opacity-50"
                    >
                      Guardar y Firmar Respaldo Manual
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Entradas & Hashes */}
          {activeTab === 'entradas' && (
            <div className="mt-3.5 space-y-2">
              {selectedNode.inputs && selectedNode.inputs.length > 0 ? (
                selectedNode.inputs.map((inp, iidx) => (
                  <div key={iidx} className="p-3 rounded-lg border border-line bg-paper/60 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-txt">{inp.name}</div>
                      <div className="text-mut text-[11px]">Origen: {inp.source} · {inp.records}</div>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-mut bg-white px-2 py-0.5 rounded border border-line">
                        SHA256: {inp.sha256}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-xs text-mut p-4 text-center border border-line rounded-lg">
                  Este nodo utiliza como entrada directa los resultados validados del nodo anterior en la cadena DAG.
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Regla CREG */}
          {activeTab === 'regla' && (
            <div className="mt-3.5 p-3.5 rounded-lg border border-line bg-paper/50 text-xs">
              <div className="font-bold text-brand mb-1">
                {selectedNode.ruleCode || workflow.reglaPrincipal}
              </div>
              <p className="text-mut text-xs leading-relaxed">
                Regulación aplicable expedida por la Comisión de Regulación de Energía y Gas (CREG) y operada por XM S.A. E.S.P. como Administrador del Sistema de Intercambios Comerciales (ASIC).
              </p>
            </div>
          )}

          {/* Tab 4: Validaciones IA (Consultas Rápidas al Agente) */}
          {activeTab === 'validaciones' && (
            <div className="mt-3.5 space-y-3">
              <div className="flex items-center justify-between text-xs text-mut">
                <span>Seleccione una pregunta para auditar la lógica del agente en este paso:</span>
                <span className="text-brand font-semibold">Respuesta inmediata sin esperas</span>
              </div>

              {/* Predefined Validation Prompts */}
              <div className="grid sm:grid-cols-2 gap-2">
                {[
                  '¿Cuál es la causa raíz de la discrepancia o alerta en este paso?',
                  '¿Cuál es la regla y artículo exacto CREG que fundamenta este resultado?',
                  '¿Qué impacto económico o regulatorio tiene si no se aprueba este paso?',
                  '¿Cómo realizo el respaldo manual sin violar el Código de Medida?',
                ].map((q, qidx) => (
                  <button
                    key={qidx}
                    onClick={() => handleQuickAgentValidation(q)}
                    className="text-left p-2.5 rounded-lg border border-line bg-paper/60 hover:bg-white hover:border-brand text-xs transition-all flex items-start gap-2"
                  >
                    <HelpCircle size={14} className="text-brand shrink-0 mt-0.5" />
                    <span className="font-medium text-txt">{q}</span>
                  </button>
                ))}
              </div>

              {/* Agent's Answer Display */}
              {agentAnswer && (
                <div className="p-3.5 rounded-lg bg-brandsoft/30 border border-brand/30 animate-in fade-in text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-brand mb-1.5">
                    <Bot size={15} />
                    <span>Dictamen del Agente · {agentAnswer.query}</span>
                  </div>
                  <p className="text-txt leading-relaxed mb-2">
                    {agentAnswer.response}
                  </p>
                  <div className="text-[11px] text-mut pt-2 border-t border-brand/20 flex items-center justify-between">
                    <span>Base Regulatoria: <b>{agentAnswer.rule}</b></span>
                    <span className="text-ok font-semibold">✓ Verificado y auditable</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Airtable Deep Data Grid (if toggled) */}
      {showAirtable && (
        <div className="p-4 md:p-5 border-t border-line bg-[#FAFBFD]">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-txt flex items-center gap-1.5">
                <Database size={15} className="text-brand" />
                <span>Auditoría Celda a Celda · Matriz de Conciliación Airtable</span>
              </h3>
              <p className="text-xs text-mut">
                Examine diferencias contra XM, reglas aplicadas y solicite explicaciones al agente.
              </p>
            </div>
          </div>

          <AirtableGrid
            rows={workflow.airtableData}
            processTitle={workflow.title}
            versionLabel={workflow.versionCiclo}
          />
        </div>
      )}
    </div>
  );
}
