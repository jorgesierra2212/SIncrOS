import React from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import {
  CheckCircle2, Clock, AlertTriangle, Loader2, Database,
  Cpu, ShieldAlert, SendHorizontal, Scale, Eye
} from 'lucide-react';
import { WorkflowNodeData } from '../../data/workflowModels';

export default function CustomFlowNode({ data, selected }: any) {
  const nodeData = (data as any) as WorkflowNodeData;

  const getStatusConfig = () => {
    switch (nodeData.status) {
      case 'completed':
        return {
          icon: CheckCircle2,
          color: 'text-ok',
          bg: 'bg-oksoft',
          border: 'border-ok/40',
          badgeText: 'Completado',
          glow: '',
        };
      case 'running':
        return {
          icon: Loader2,
          color: 'text-brand',
          bg: 'bg-brandsoft',
          border: 'border-brand',
          badgeText: 'En ejecución',
          glow: 'ring-2 ring-brand/30 ring-offset-1 animate-pulse',
        };
      case 'action_required':
        return {
          icon: AlertTriangle,
          color: 'text-bad',
          bg: 'bg-badsoft',
          border: 'border-bad',
          badgeText: 'Acción Requerida (!)',
          glow: 'ring-2 ring-bad/30 ring-offset-1',
        };
      default:
        return {
          icon: Clock,
          color: 'text-mut',
          bg: 'bg-paper',
          border: 'border-line',
          badgeText: 'Pendiente',
          glow: '',
        };
    }
  };

  const statusConfig = getStatusConfig();
  const StatusIcon = statusConfig.icon;

  const getCategoryIcon = () => {
    switch (nodeData.category) {
      case 'ingesta':
        return Database;
      case 'agente':
        return Cpu;
      case 'aprobacion':
        return ShieldAlert;
      case 'transmision':
        return SendHorizontal;
      default:
        return Scale;
    }
  };

  const CategoryIcon = getCategoryIcon();

  return (
    <div
      className={`w-[240px] rounded-lg bg-white border text-left transition-all shadow-xs cursor-pointer ${
        selected ? 'ring-2 ring-brand border-brand shadow-md' : statusConfig.border
      } ${statusConfig.glow}`}
    >
      {/* Target handle on left */}
      <Handle
        type="target"
        position={Position.Left}
        className="w-2.5 h-2.5 !bg-mut border-2 !border-white transition-transform hover:scale-125"
      />

      {/* Node Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-line/60 bg-paper/60 rounded-t-lg">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono font-bold text-mut bg-white px-1.5 py-0.5 rounded border border-line">
            #{String(nodeData.stepNumber).padStart(2, '0')}
          </span>
          <CategoryIcon size={12} className="text-mut" />
          <span className="text-[10px] uppercase font-bold tracking-wider text-mut truncate max-w-[85px]">
            {nodeData.category}
          </span>
        </div>

        <div className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded ${statusConfig.bg} ${statusConfig.color}`}>
          <StatusIcon size={10} className={nodeData.status === 'running' ? 'animate-spin' : ''} />
          <span>{statusConfig.badgeText}</span>
        </div>
      </div>

      {/* Node Body */}
      <div className="p-3">
        <h4 className="text-xs font-bold text-txt leading-snug line-clamp-2">
          {nodeData.label}
        </h4>
        <p className="text-[11px] text-mut mt-1 line-clamp-2 leading-relaxed">
          {nodeData.shortDesc}
        </p>

        {nodeData.actionRequiredNotice && (
          <div className="mt-2 text-[10px] font-medium text-bad bg-badsoft px-2 py-1 rounded border border-bad/20 leading-tight">
            ⚠️ {nodeData.actionRequiredNotice}
          </div>
        )}

        {/* Footer meta */}
        <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-line/40 text-[10px] text-mut">
          <span className="truncate max-w-[130px] font-medium text-txt">
            {nodeData.executor}
          </span>
          {nodeData.duration && (
            <span className="font-mono text-mut bg-paper px-1 py-0.2 rounded">
              {nodeData.duration}
            </span>
          )}
        </div>
      </div>

      {/* Source handle on right */}
      <Handle
        type="source"
        position={Position.Right}
        className="w-2.5 h-2.5 !bg-brand border-2 !border-white transition-transform hover:scale-125"
      />
    </div>
  );
}
